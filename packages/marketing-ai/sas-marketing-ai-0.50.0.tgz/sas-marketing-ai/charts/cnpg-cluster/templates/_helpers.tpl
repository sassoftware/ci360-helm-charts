{{/*
Resolve the image-manager ECR registry and repository from global.ExternalGatewayHost.
*/}}
{{- define "cnpg-cluster.ecrConfig" -}}
{{- $fullPathMap := dict
  "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
  "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
  "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
  "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $global := .Values.global | default dict -}}
{{- $fullPath := get $fullPathMap ($global.ExternalGatewayHost | default "") -}}
{{- if $fullPath -}}
{{- dict "fullPath" $fullPath | toYaml -}}
{{- else -}}
{{- dict "fullPath" "" | toYaml -}}
{{- end -}}
{{- end -}}

{{/*
Returns the PostgreSQL image. An explicit image.repository wins. Image-manager tags (lic_mai.*)
exist only in the ECR repository for global.ExternalGatewayHost, so they require a mapped host.
Any other tag uses the upstream CNPG image.
*/}}
{{- define "cnpg-cluster.image" -}}
{{- $ecrConfig := include "cnpg-cluster.ecrConfig" . | fromYaml -}}
{{- $tag := toString .Values.image.tag -}}
{{- $repository := .Values.image.repository -}}
{{- if not $repository -}}
{{- if hasPrefix "lic_mai." $tag -}}
{{- if not $ecrConfig.fullPath -}}
{{- fail (printf "cnpg-cluster: image tag '%s' is an image-manager tag that exists only in ECR. Set global.ExternalGatewayHost to a supported gateway host (currently '%s') or set image.repository." $tag ((.Values.global | default dict).ExternalGatewayHost | default "")) -}}
{{- end -}}
{{- $repository = $ecrConfig.fullPath -}}
{{- else -}}
{{- $repository = "ghcr.io/cloudnative-pg/postgresql" -}}
{{- end -}}
{{- end -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
