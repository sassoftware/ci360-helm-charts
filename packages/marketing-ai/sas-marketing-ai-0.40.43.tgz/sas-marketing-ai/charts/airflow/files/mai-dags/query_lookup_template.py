from datetime import datetime, timedelta
from airflow.decorators import dag, task
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator

default_args = {
    'retries': 3, 
    'retry_delay': timedelta(seconds=1),
    'queue': 'high-priority'
}

@dag (
    schedule=None,
    start_date=datetime(2024, 11, 5),
    catchup=False,
    tags=['Marketing AI Internal Query Workflows'],
    default_args=default_args,
    params={"conn_id":"demo_conn_pg_airflow", "queries":["SELECT DISTINCT id FROM dag_run LIMIT 10;", "SELECT DISTINCT state FROM dag_run LIMIT 10;"]},
    render_template_as_native_obj=True
    )
def query_lookup():
    task = SQLExecuteQueryOperator(
        task_id="query_lookup_task",
        sql='{{params.queries}}',
        conn_id='{{params.conn_id}}',
        split_statements=True,
        return_last=False
    )
query_lookup()