import pendulum
from airflow.decorators import dag
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from datetime import timedelta

default_args = {
    'retries': 3, 
    'retry_delay': timedelta(seconds=1),
    'queue': 'high-priority'
}

@dag(
    schedule=None,
    start_date=pendulum.datetime(2024, 11, 5, tz="UTC"),
    catchup=False,
    tags=['Marketing AI Internal Query Workflows'],
    default_args=default_args,
    params={"conn_id": "demo_conn_pg_airflow",
            "table_metadata": "select 1;",
            "column_metadata": "select 1;"})
def query_metadata():
    table_metadata_stmt = SQLExecuteQueryOperator(
        conn_id="{{params.conn_id}}",
        task_id="query_table_metadata_task",
        sql="{{params.table_metadata}}"
    )

    column_metadata_stmt = SQLExecuteQueryOperator(
        conn_id="{{params.conn_id}}",
        task_id="query_column_metadata_task",
        sql="{{params.column_metadata}}"
    )


query_metadata()