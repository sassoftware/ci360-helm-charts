import pendulum
from airflow.decorators import dag
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from datetime import timedelta

default_args = {
    'retries': 3, 
    'retry_delay': timedelta(seconds=1),
    'queue': 'high-priority'
}

@dag(
    schedule=None,
    start_date=pendulum.datetime(2024, 11, 5, tz="UTC"),
    catchup=False,
    tags=['Marketing AI Internal Query Workflows'],
    default_args=default_args,
    params={"conn_id": "demo_conn_pg_airflow"})
def validate_connection():
    q0 = "select 1;"

    postgres_single_stmt0 = SQLExecuteQueryOperator(
        conn_id="{{params.conn_id}}",
        task_id="query_validate_connection_task",
        sql=q0
    )


validate_connection()