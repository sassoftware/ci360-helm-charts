from airflow.sdk import dag, task
from mai_global import logger
from maicompute.recipes.common.api import metadata
from datetime import timedelta

default_args = {
    'retries': 3, 
    'retry_delay': timedelta(seconds=1),
    'queue': 'high-priority'
}

@dag(
    dag_id="connection_metadata",
    description="Branching TaskFlow DAG for metadata operations, each branch returning its own XCom output",
    catchup=False,
    tags=['Marketing AI Internal Connection Metadata Workflows'],
    schedule=None,
    default_args=default_args,
    params={
        "conn_id": "A-mai-snowflake-1",
        "connection_type": "snowflake",
        "operation": "validate_connection"
    },
)
def connection_metadata_dag():
    """Branching TaskFlow DAG where each task returns its own result via XCom."""

    @task.branch()
    def choose_operation(**context):
        conf = context["dag_run"].conf or {}
        logger.info(conf)
        connection_id = conf.get("conn_id")
        connection_type = conf.get("connection_type")
        operation = conf.get("operation")

        if not connection_id or not connection_type or not operation:
            raise ValueError("Missing required parameters: connection_id, connection_type, operation")

        logger.info(f"Branching decision based on operation: {operation}")

        if operation == "validate_connection":
            return "validate_connection"
        elif operation == "query_table_list":
            return "query_table_list"
        elif operation == "query_table_columns":
            return "query_table_columns"
        elif operation == "query_table_preview":
            return "query_table_preview"
        elif operation == "query_table_column_values":
            return "query_table_column_values"
        else:
            return "unsupported_operation"

    @task(task_id="validate_connection")
    def validate_connection_task(**context):
        conf = context["dag_run"].conf
        return metadata.validate_connection(conf)

    @task(task_id="query_table_list")
    def list_tables_task(**context):
        conf = context["dag_run"].conf
        return metadata.list_tables(conf)

    @task(task_id="query_table_columns")
    def list_columns_task(**context):
        conf = context["dag_run"].conf
        return metadata.list_columns(conf)

    @task(task_id="query_table_preview")
    def table_preview_task(**context):
        conf = context["dag_run"].conf
        return metadata.table_preview(conf)

    @task(task_id="query_table_column_values")
    def table_column_values_task(**context):
        conf = context["dag_run"].conf
        return metadata.table_column_values(conf)

    @task(task_id="query_datasource_preview")
    def datasource_preview_task(**context):
        conf = context["dag_run"].conf
        return metadata.datasource_preview(conf)

    @task(task_id="unsupported_operation")
    def unsupported_operation_task(**context):
        conf = context["dag_run"].conf
        operation = conf.get("operation")
        logger.error(f"Unsupported operation: {operation}")
        return {"status": "error", "message": f"Unsupported operation: {operation}"}

    # Branching structure: only one task executes each run
    branch = choose_operation()

    branch >> [
        validate_connection_task(),
        list_tables_task(),
        list_columns_task(),
        table_preview_task(),
        table_column_values_task(),
        datasource_preview_task(),
        unsupported_operation_task(),
    ]

dag = connection_metadata_dag()
