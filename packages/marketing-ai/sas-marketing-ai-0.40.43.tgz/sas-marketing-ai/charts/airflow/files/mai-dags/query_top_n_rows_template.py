import pendulum
from airflow.decorators import dag
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from datetime import timedelta

default_args = {
    'retries': 3, 
    'retry_delay': timedelta(seconds=1),
    'queue': 'high-priority'
}

@dag(
    schedule=None,
    start_date=pendulum.datetime(2024, 11, 5, tz="UTC"),
    catchup=False,
    tags=['Marketing AI Internal Query Workflows'],
    default_args=default_args,
    params={"conn_id": "demo_conn_pg_airflow", "query": "select * from dag;"})
def query_top_n_rows():
    query_lookup_pg_stmt2 = SQLExecuteQueryOperator(
        conn_id="{{params.conn_id}}",
        task_id="query_top_n_rows_task",
        sql="{{params.query}}"
    )


query_top_n_rows()