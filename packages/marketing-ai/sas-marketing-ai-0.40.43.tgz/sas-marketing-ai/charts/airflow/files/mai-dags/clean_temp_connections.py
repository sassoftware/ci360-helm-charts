from __future__ import annotations
import json
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any
from airflow.sdk import dag, task, get_current_context
from airflow.sdk import Variable
from mai_global import logger
from mai_global.airflow_api_requests import airflow_api_request

DEFAULT_MAX_AGE_HOURS = 3
DEFAULT_PAGE_LIMIT = 100
TEMP_PREFIX = "TEMP_"

@dataclass
class TempConnection:
    connection_id: str
    created_at: datetime

def _parse_temp_from_description(desc_raw: Any) -> tuple[bool, datetime | None]:
    """
    Parse temp_connection and temp_created_at from a JSON‑string in description.

    Expected desc_raw:
        '{"temp_connection": true, "temp_created_at": "2026-03-31T01:00:00Z"}'
    """
    if not isinstance(desc_raw, str):
        return False, None

    try:
        data = json.loads(desc_raw)
        if not isinstance(data, dict):
            return False, None

        temp_conn = bool(data.get("temp_connection"))
        ts = data.get("temp_created_at")
        if not ts or not isinstance(ts, str):
            return temp_conn, None

        ts = ts.replace("Z", "+00:00")
        created = datetime.fromisoformat(ts)
        return temp_conn, created

    except (json.JSONDecodeError, ValueError, TypeError):
        return False, None

@task(retries=2, retry_delay=timedelta(minutes=5))
def cleanup_temp_connections() -> None:
    # Use the correct context getter
    context = get_current_context()
    dag_run_conf = context.get("dag_run", {}).conf or {}

    # 1. max_age_hours
    max_age_hours_str = dag_run_conf.get("max_age_hours")
    if max_age_hours_str is not None:
        max_age_hours = int(max_age_hours_str)
    else:
        try:
            max_age_hours = int(
                Variable.get(
                    "MAI_CLEANUP_TEMP_CONNECTIONS_MAX_AGE_HOURS",
                    default=str(DEFAULT_MAX_AGE_HOURS),
                )
            )
        except Exception:
            max_age_hours = DEFAULT_MAX_AGE_HOURS

    # 2. page_limit
    page_limit_str = dag_run_conf.get("page_limit")
    if page_limit_str is not None:
        page_limit = int(page_limit_str)
    else:
        try:
            page_limit = int(
                Variable.get(
                    "MAI_CLEANUP_TEMP_CONNECTIONS_PAGE_LIMIT",
                    default=str(DEFAULT_PAGE_LIMIT),
                )
            )
        except Exception:
            page_limit = DEFAULT_PAGE_LIMIT

    airflow_url = os.environ["AIRFLOW_WEBSERVER_URL"].rstrip("/")
    cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
    logger.info(f"Cutoff datetime (UTC): {cutoff.isoformat()}")

    offset = 0
    candidates: list[TempConnection] = []
    seen_ids: set[str] = set()

    while True:
        params = {
            "offset": offset,
            "limit": page_limit,
            "connection_id_pattern": f"{TEMP_PREFIX}%",
        }

        resp = airflow_api_request.get(
            f"{airflow_url}/api/v2/connections",
            params=params,
            timeout=30,
        )
        resp.raise_for_status()
        payload = resp.json()

        items = payload.get("connections") or payload.get("items") or []
        if not items:
            break

        for c in items:
            cid = c.get("connection_id")
            if not cid or cid in seen_ids:
                logger.info(f"Skipping connection: {cid}")
                continue

            description = c.get("description")
            temp_conn, created = _parse_temp_from_description(description)

            if not temp_conn:
                logger.info(f"Did not treat {cid} as temp: temp_conn={temp_conn}")
                continue

            if not created:
                logger.info(f"Skipping {cid}: no valid created time")
                continue

            if created > cutoff:
                logger.info(f"Skipping {cid}: created={created.isoformat()} > cutoff={cutoff.isoformat()}")
                continue

            logger.info(f"CANDIDATE: {cid} (created={created.isoformat()})")
            seen_ids.add(cid)
            candidates.append(TempConnection(connection_id=cid, created_at=created))

        if len(items) < page_limit:
            break

        offset += page_limit

    deleted: list[str] = []
    failed: list[dict[str, str]] = []

    for conn in candidates:
        logger.info(f"Trying to delete {conn.connection_id}")
        try:
            dr = airflow_api_request.delete(
                f"{airflow_url}/api/v2/connections/{conn.connection_id}",
                timeout=30,
            )
            if dr.status_code in (200, 204):
                logger.info(f"Deleted {conn.connection_id}")
                deleted.append(conn.connection_id)
            elif dr.status_code == 404:
                logger.info(f"{conn.connection_id} already gone (404)")
                deleted.append(conn.connection_id)
            else:
                logger.error(f"Failed to delete {conn.connection_id}: {dr.status_code} {dr.text[:300]}")
                failed.append(
                    {
                        "connection_id": conn.connection_id,
                        "status_code": str(dr.status_code),
                        "response": dr.text[:500],
                    }
                )
        except Exception as exc:
            logger.error(f"Exception when deleting {conn.connection_id}: {exc!r}")
            failed.append(
                {
                    "connection_id": conn.connection_id,
                    "error": str(exc),
                }
            )

    logger.info(f"Deleted {len(deleted)} TEMP connections.")
    if failed:
        logger.info(f"Failed deletions: {len(failed)}")
    else:
        logger.info("No failures.")


@dag(
    dag_id="cleanup_temp_connections",
    is_paused_upon_creation=False,
    schedule="0 * * * *",
    start_date=datetime(2026, 3, 31, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    default_args={
        "queue": "high-priority",
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
    },
    tags=["Marketing AI Internal Connection Cleanup", "maintenance"],
)
def cleanup_temp_connections_dag():
    cleanup_temp_connections()


dag = cleanup_temp_connections_dag()
