{{/*
Expand the name of the chart.
*/}}
{{- define "satellite.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "local-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "local-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "local-agent.labels" -}}
helm.sh/chart: {{ include "local-agent.chart" . }}
{{ include "local-agent.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "local-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "local-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "local-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "local-agent.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Enable fallback credential generation only when explicitly requested.
Values drive this behavior; CI can map environment variables to --set flags.
*/}}
{{- define "local-agent.pgFallbackCredentialsEnabled" -}}
{{- $enabled := false -}}
{{- if and (hasKey .Values "pg_fallback_credentials") (hasKey .Values.pg_fallback_credentials "enabled") -}}
    {{- $enabled = .Values.pg_fallback_credentials.enabled -}}
{{- end -}}
{{- $enabledText := printf "%v" $enabled | lower -}}
{{- if or (eq $enabledText "true") (eq $enabledText "1") (eq $enabledText "yes") -}}
true
{{- end -}}
{{- end }}

{{- define "local-agent.postgresPassword" -}}
{{- $existing := (lookup "v1" "Secret" .Release.Namespace "postgres-credentials") -}}
{{- if and $existing $existing.data (index $existing.data "password") -}}
{{- index $existing.data "password" | b64dec -}}
{{- else if include "local-agent.pgFallbackCredentialsEnabled" . -}}
{{- if and (hasKey .Values "pg_fallback_credentials") (not (empty .Values.pg_fallback_credentials.postgresPassword)) -}}
{{- .Values.pg_fallback_credentials.postgresPassword -}}
{{- else -}}
{{- randAlphaNum 32 -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Name of the Secret holding the Redis password.
*/}}
{{- define "local-agent.redisSecretName" -}}
{{- $redis := .Values.redis | default dict -}}
{{- default "redis-credentials" (dig "auth" "existingSecret" "" $redis) -}}
{{- end }}

{{/*
Key inside the Redis Secret holding the password.
*/}}
{{- define "local-agent.redisSecretPasswordKey" -}}
{{- $redis := .Values.redis | default dict -}}
{{- default "redis-password" (dig "auth" "existingSecretPasswordKey" "" $redis) -}}
{{- end }}

{{/*
Resolve the Redis password once per render and cache it, so every template that
consumes it (redis-secret, redis-broker-url, ...) gets the identical value.
*/}}
{{- define "local-agent.redisPassword" -}}
{{- if not (hasKey .Values "_resolvedRedisPassword") -}}
{{- $secretName := include "local-agent.redisSecretName" . -}}
{{- $secretKey := include "local-agent.redisSecretPasswordKey" . -}}
{{- $existing := (lookup "v1" "Secret" .Release.Namespace $secretName) -}}
{{- $password := "" -}}
{{- if and $existing $existing.data (index $existing.data $secretKey) -}}
{{- $password = index $existing.data $secretKey | b64dec -}}
{{- else if not (empty (dig "auth" "password" "" (.Values.redis | default dict))) -}}
{{- $password = .Values.redis.auth.password -}}
{{- else if include "local-agent.redisFallbackCredentialsEnabled" . -}}
{{- $password = default (randAlphaNum 32) (dig "redisPassword" "" (.Values.redis_fallback_credentials | default dict)) -}}
{{- else if $existing -}}
{{- fail (printf "Secret %s is missing key '%s'" $secretName $secretKey) -}}
{{- else -}}
{{- fail (printf "Secret %s not found in namespace %s. Pre-create it with key '%s' or set redis_fallback_credentials.enabled=true." $secretName .Release.Namespace $secretKey) -}}
{{- end -}}
{{- $_ := set .Values "_resolvedRedisPassword" $password -}}
{{- end -}}
{{- .Values._resolvedRedisPassword -}}
{{- end }}

{{/*
Enable fallback Redis credential generation only when explicitly requested.
*/}}
{{- define "local-agent.redisFallbackCredentialsEnabled" -}}
{{- $enabled := false -}}
{{- if and (hasKey .Values "redis_fallback_credentials") (hasKey .Values.redis_fallback_credentials "enabled") -}}
    {{- $enabled = .Values.redis_fallback_credentials.enabled -}}
{{- end -}}
{{- $enabledText := printf "%v" $enabled | lower -}}
{{- if or (eq $enabledText "true") (eq $enabledText "1") (eq $enabledText "yes") -}}
true
{{- end -}}
{{- end }}

{{- define "local-agent.repmgrPassword" -}}
{{- $existing := (lookup "v1" "Secret" .Release.Namespace "postgres-credentials") -}}
{{- if and $existing $existing.data (index $existing.data "repmgr-password") -}}
{{- index $existing.data "repmgr-password" | b64dec -}}
{{- else if include "local-agent.pgFallbackCredentialsEnabled" . -}}
{{- if and (hasKey .Values "pg_fallback_credentials") (not (empty .Values.pg_fallback_credentials.repmgrPassword)) -}}
{{- .Values.pg_fallback_credentials.repmgrPassword -}}
{{- else if and (hasKey .Values "pg_fallback_credentials") (not (empty .Values.pg_fallback_credentials.postgresPassword)) -}}
{{- .Values.pg_fallback_credentials.postgresPassword -}}
{{- else -}}
{{- randAlphaNum 10 -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "local-agent.pgpoolPassword" -}}
{{- $existing := (lookup "v1" "Secret" .Release.Namespace "pgpool-credentials") -}}
{{- if and $existing $existing.data (index $existing.data "admin-password") -}}
{{- index $existing.data "admin-password" | b64dec -}}
{{- else if include "local-agent.pgFallbackCredentialsEnabled" . -}}
{{- if and (hasKey .Values "pg_fallback_credentials") (not (empty .Values.pg_fallback_credentials.pgpoolAdminPassword)) -}}
{{- .Values.pg_fallback_credentials.pgpoolAdminPassword -}}
{{- else if and (hasKey .Values "pg_fallback_credentials") (not (empty .Values.pg_fallback_credentials.postgresPassword)) -}}
{{- .Values.pg_fallback_credentials.postgresPassword -}}
{{- else -}}
{{- randAlphaNum 10 -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Resolve the ECR registry URL from global.ExternalGatewayHost.
Returns the full registry host: <accountID>.dkr.ecr.<region>.amazonaws.com
*/}}
{{- define "local-agent.ecrRegistry" -}}
{{- $fullPathMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $fullPath := get $fullPathMap $host -}}
{{- if $fullPath -}}
{{- $parts := splitList "/" $fullPath -}}
{{- first $parts -}}
{{- else -}}
{{- fail (printf "Unknown ExternalGatewayHost '%s'. Valid values: extapigwservice-dev.cidev.sas.us, extapigwservice-stage.cistage.sas.com, extapigwservice-prod.ci360.sas.com, extapigwservice-training.ci360.sas.com, extapigwservice-eu-prod.ci360.sas.com, extapigwservice-apn-prod.ci360.sas.com, extapigwservice-syd-prod.ci360.sas.com, extapigwservice-mum-prod.ci360.sas.com, extapigwservice-demo.cidemo.sas.com" $host) -}}
{{- end -}}
{{- end -}}

{{/*
Resolve the ECR image base path from global.ExternalGatewayHost.
Returns the full path: <registry>/ci360-cldeng-image-manager/shared-images-<env>
*/}}
{{- define "local-agent.ecrImageBase" -}}
{{- $fullPathMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- get $fullPathMap $host -}}
{{- end -}}

{{/*
Get API token URL from global.ExternalGatewayHost.
Returns: https://<ExternalGatewayHost>/token
*/}}
{{- define "local-agent.apiTokenUrl" -}}
{{- if .Values.global.ExternalGatewayHost -}}
{{- printf "https://%s/token" .Values.global.ExternalGatewayHost -}}
{{- else if .Values.api.tokenUrl -}}
{{- .Values.api.tokenUrl -}}
{{- else -}}
{{- fail "Either global.ExternalGatewayHost or api.tokenUrl must be set" -}}
{{- end -}}
{{- end -}}

{{/*
Get API final URL from global.ExternalGatewayHost.
Returns: https://<ExternalGatewayHost>/marketingContainerImage/token
*/}}
{{- define "local-agent.apiFinalUrl" -}}
{{- if .Values.global.ExternalGatewayHost -}}
{{- printf "https://%s/marketingContainerImage/token" .Values.global.ExternalGatewayHost -}}
{{- else if .Values.api.finalUrl -}}
{{- .Values.api.finalUrl -}}
{{- else -}}
{{- fail "Either global.ExternalGatewayHost or api.finalUrl must be set" -}}
{{- end -}}
{{- end -}}