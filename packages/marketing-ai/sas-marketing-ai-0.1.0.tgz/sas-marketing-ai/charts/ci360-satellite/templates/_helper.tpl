{{/*
Expand the name of the chart.
*/}}
{{- define "ci360-mkt-ai.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ci360-mkt-ai.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ci360-mkt-ai.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ci360-mkt-ai.labels" -}}
helm.sh/chart: {{ include "ci360-mkt-ai.chart" . }}
{{ include "ci360-mkt-ai.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ci360-mkt-ai.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ci360-mkt-ai.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
team: analytics
{{- end }}
{{/*
MAI Proxy Selector labels
*/}}
{{- define "ci360-mkt-ai-proxy.labels" -}}
helm.sh/chart: {{ include "ci360-mkt-ai.chart" . }}
{{ include "ci360-mkt-ai-proxy.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ci360-mkt-ai-proxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ci360-mkt-ai.name" . }}-proxy
app.kubernetes.io/instance: {{ .Release.Name }}-proxy
team: analytics
{{- end }}
{{/*
MAI Orchestration Selector labels
*/}}
{{- define "ci360-mkt-ai-orchestra.labels" -}}
helm.sh/chart: {{ include "ci360-mkt-ai.chart" . }}
{{ include "ci360-mkt-ai-orchestra.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "ci360-mkt-ai-orchestra.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ci360-mkt-ai.name" . }}-orchestra
app.kubernetes.io/instance: {{ .Release.Name }}-orchestra
team: analytics
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ci360-mkt-ai.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ci360-mkt-ai.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create normalized namespace (in dev environment, this will resolve to the branch name minus any underscores, slashes, dashes, uppercase letters)
*/}}
{{- define "ci360-mkt-ai.namespace" -}}
{{- if (eq .Release.Namespace "ci360-mkt-ai") }}
{{- .Values.environment.shortname }}
{{- else }}
{{- printf "%s" .Release.Namespace | lower | replace "_" "" | replace "\\" "" | replace "-" "" | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create value that equates to the unfortunately named terraform variable called "environment"
*/}}
{{- define "ci360-mkt-ai.envPrefix" -}}
{{- $prodEnvs := list "apn" "euw" "mum" "use" "syd" }}
{{- if (mustHas .Values.environment.shortname $prodEnvs) }}
{{- printf "prod-%s" .Values.environment.shortname }}
{{- else }}
{{- .Values.environment.shortname }}
{{- end }}
{{- end }}

{{/*
Create the stack prefix to use
*/}}
{{- define "ci360-mkt-ai.stackprefix" -}}
{{- .Values.StackPrefixValue }}
{{- end }}

{{/*
Create the service URL to use
*/}}
{{- define "ci360-mkt-ai.serviceUrl" -}}
{{- if (eq .Release.Namespace "ci360-mkt-ai") }}
{{- printf "http://%s.%s:8080/mai" (include "ci360-mkt-ai.fullname" .) .Values.hostedZoneDomainName -}}
{{- else }}
{{- printf "http://%s-%s.%s:8080/mai" (include "ci360-mkt-ai.fullname" .) .Values.StackPrefixValue .Values.hostedZoneDomainName -}}
{{- end }}
{{- end }}

{{- define "ci360-mkt-ai-proxy.serviceUrl" -}}
{{- printf "http://%s-proxy.%s.svc.cluster.local" (include "ci360-mkt-ai.fullname" .) .Release.Namespace }}
{{/*- printf "http://%s-proxy.%s/analyticmai" (include "ci360-mkt-ai.fullname" .) .Values.hostedZoneDomainName -*/}}
{{- end }}

{{- define "ci360-mkt-ai-orchestra.serviceUrl" -}}
{{- printf "http://%s-orchestra.%s.svc.cluster.local" (include "ci360-mkt-ai.fullname" .) .Release.Namespace }}
{{/*- printf "http://%s-orchestra.%s/analyticmai" (include "ci360-mkt-ai.fullname" .) .Values.hostedZoneDomainName -*/}}
{{- end }}

{{- define "airflow_url" -}}
    {{- printf "http://%s-airflow-api-server:8080" .Release.Name }}
{{- end }}

{{/*
Compute ECR registry and full image path from global.ExternalGatewayHost
This allows ci360-satellite to determine the correct image registry without hardcoding in values files
*/}}
{{- define "ci360-satellite.ecrConfig" -}}
{{- $fullPathMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $fullPath := "" -}}
{{- $registry := "" -}}
{{- $repository := "" -}}
{{- if $host -}}
  {{- $fullPath = get $fullPathMap $host -}}
  {{- if $fullPath -}}
    {{- $parts := splitList "/" $fullPath -}}
    {{- $registry = index $parts 0 -}}
    {{- $repository = printf "%s/%s" (index $parts 1) (index $parts 2) -}}
  {{- end -}}
{{- end -}}
{{- if not $registry -}}
  {{- $registry = .Values.global.imageRegistry | default "" -}}
{{- end -}}
{{- $result := dict "registry" $registry "repository" $repository "fullPath" $fullPath -}}
{{- $result | toYaml -}}
{{- end -}}

{{/*
Return the proper ci360-satellite orchestra image
*/}}
{{- define "ci360-satellite.image" -}}
{{- $ecrConfig := include "ci360-satellite.ecrConfig" . | fromYaml -}}
{{- if .Values.image.repository -}}
  {{- /* Respect explicitly set repository from --set commands */ -}}
  {{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default "latest") -}}
{{- else if and $ecrConfig $ecrConfig.fullPath -}}
  {{- /* Fall back to ECR mapping if no explicit repository set */ -}}
  {{- printf "%s:%s" $ecrConfig.fullPath (.Values.image.tag | default "latest") -}}
{{- else -}}
  {{- /* Default fallback */ -}}
  {{- printf "%s:%s" (.Values.image.repository | default "ci360-satellite") (.Values.image.tag | default "latest") -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper ci360-satellite proxy image
*/}}
{{- define "ci360-satellite.proxyImage" -}}
{{- $ecrConfig := include "ci360-satellite.ecrConfig" . | fromYaml -}}
{{- if .Values.image.proxy.repository -}}
  {{- /* Respect explicitly set proxy repository from --set commands */ -}}
  {{- printf "%s:%s" .Values.image.proxy.repository (.Values.image.proxy.tag | default "latest") -}}
{{- else if and $ecrConfig $ecrConfig.fullPath -}}
  {{- /* Fall back to ECR mapping if no explicit proxy repository set */ -}}
  {{- printf "%s:%s" $ecrConfig.fullPath (.Values.image.proxy.tag | default "latest") -}}
{{- else -}}
  {{- /* Default fallback */ -}}
  {{- printf "%s:%s" (.Values.image.proxy.repository | default "ci360-satellite-proxy") (.Values.image.proxy.tag | default "latest") -}}
{{- end -}}
{{- end -}}