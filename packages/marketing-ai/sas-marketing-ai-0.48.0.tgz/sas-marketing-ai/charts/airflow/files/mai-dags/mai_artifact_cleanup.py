from datetime import datetime, timedelta, timezone

from airflow.sdk import dag, get_current_context, task
from maicompute.tasks.blob_cleanup import discover_and_delete_artifacts


@dag(
    dag_id="mai_artifact_cleanup",
    description="Delete Recipe and Project artifacts recorded by cleanup manifests",
    schedule="30 2 * * *",
    start_date=datetime(2026, 10, 16, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    dagrun_timeout=timedelta(hours=10),
    is_paused_upon_creation=False,
    default_args={
        "queue": "high-priority",
        "retries": 1,
        "retry_delay": timedelta(minutes=2),
    },
    tags=["Marketing AI Internal Artifact Cleanup", "maintenance"],
)
def artifact_cleanup_dag():
    # Deletes each manifest once all its prefixes are deleted. Each manifest saves
    # its prefix progress, so the Airflow retry skips work that is already done.
    @task(
        task_id="discover_and_delete_artifacts",
        execution_timeout=timedelta(hours=3),
    )
    def discover_and_delete():
        context = get_current_context()
        # The mai-dags ConfigMap adds this deployment's tenant tag. Without it the
        # tenant stays empty and the task fails before deleting anything.
        tenant_moniker = ""
        for tag in context["dag"].tags:
            if tag.startswith("tenant_moniker_"):
                tenant_moniker = tag.removeprefix("tenant_moniker_")
        discover_and_delete_artifacts(
            run_id=context["run_id"],
            tenant_moniker=tenant_moniker,
        )

    discover_and_delete()


dag = artifact_cleanup_dag()
