{{/*
Copyright Broadcom, Inc. All Rights Reserved.
SPDX-License-Identifier: APACHE-2.0
*/}}

{{/* vim: set filetype=mustache: */}}

{{/*
Compute ECR registry and repository from global.ExternalGatewayHost
This allows Redis to determine the correct image registry without hardcoding in values files
*/}}
{{- define "redis.ecrConfig" -}}
{{- $fullPathMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $fullPath := "" -}}
{{- $registry := "" -}}
{{- $repository := "" -}}
{{- if $host -}}
  {{- $fullPath = get $fullPathMap $host -}}
  {{- if $fullPath -}}
    {{- $parts := splitList "/" $fullPath -}}
    {{- $registry = index $parts 0 -}}
    {{- $repository = printf "%s/%s" (index $parts 1) (index $parts 2) -}}
  {{- end -}}
{{- end -}}
{{- if not $registry -}}
  {{- $registry = .Values.global.imageRegistry | default "" -}}
{{- end -}}
{{- $result := dict "registry" $registry "repository" $repository -}}
{{- $result | toYaml -}}
{{- end -}}

{{/*
Return the proper Redis image name
*/}}
{{- define "redis.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.image.tag | default "") "digest" (.Values.image.digest | default "") "pullPolicy" (.Values.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return the proper Redis Sentinel image name
*/}}
{{- define "redis.sentinel.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.sentinel.image.tag | default "") "digest" (.Values.sentinel.image.digest | default "") "pullPolicy" (.Values.sentinel.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.sentinel.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return the proper image name (for the metrics image)
*/}}
{{- define "redis.metrics.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.metrics.image.tag | default "") "digest" (.Values.metrics.image.digest | default "") "pullPolicy" (.Values.metrics.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.metrics.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return the proper image name (for the init container volume-permissions image)
*/}}
{{- define "redis.volumePermissions.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.volumePermissions.image.tag | default "") "digest" (.Values.volumePermissions.image.digest | default "") "pullPolicy" (.Values.volumePermissions.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.volumePermissions.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return kubectl image
*/}}
{{- define "redis.kubectl.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.kubectl.image.tag | default "") "digest" (.Values.kubectl.image.digest | default "") "pullPolicy" (.Values.kubectl.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.kubectl.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return sysctl image
*/}}
{{- define "redis.sysctl.image" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- $imageRoot := dict -}}
{{- if $ecrConfig.registry -}}
  {{- $imageRoot = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.sysctl.image.tag | default "") "digest" (.Values.sysctl.image.digest | default "") "pullPolicy" (.Values.sysctl.image.pullPolicy | default "IfNotPresent") -}}
{{- else -}}
  {{- $imageRoot = .Values.sysctl.image -}}
{{- end -}}
{{ include "common.images.image" (dict "imageRoot" $imageRoot "global" .Values.global) }}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "redis.imagePullSecrets" -}}
{{- include "common.images.renderPullSecrets" (dict "images" (list .Values.image .Values.sentinel.image .Values.metrics.image .Values.volumePermissions.image .Values.sysctl.image) "context" $) -}}
{{- end -}}

{{/*
Return true if a TLS secret object should be created
*/}}
{{- define "redis.createTlsSecret" -}}
{{- if and .Values.tls.enabled .Values.tls.autoGenerated (and (not .Values.tls.existingSecret) (not .Values.tls.certificatesSecret)) }}
    {{- true -}}
{{- end -}}
{{- end -}}

{{/*
Return the secret containing Redis TLS certificates
*/}}
{{- define "redis.tlsSecretName" -}}
{{- $secretName := coalesce .Values.tls.existingSecret .Values.tls.certificatesSecret -}}
{{- if $secretName -}}
    {{- printf "%s" (tpl $secretName $) -}}
{{- else -}}
    {{- printf "%s-crt" (include "common.names.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return the path to the cert file.
*/}}
{{- define "redis.tlsCert" -}}
{{- if (include "redis.createTlsSecret" . ) -}}
    {{- printf "/opt/bitnami/redis/certs/%s" "tls.crt" -}}
{{- else -}}
    {{- required "Certificate filename is required when TLS in enabled" .Values.tls.certFilename | printf "/opt/bitnami/redis/certs/%s" -}}
{{- end -}}
{{- end -}}

{{/*
Return the path to the cert key file.
*/}}
{{- define "redis.tlsCertKey" -}}
{{- if (include "redis.createTlsSecret" . ) -}}
    {{- printf "/opt/bitnami/redis/certs/%s" "tls.key" -}}
{{- else -}}
    {{- required "Certificate Key filename is required when TLS in enabled" .Values.tls.certKeyFilename | printf "/opt/bitnami/redis/certs/%s" -}}
{{- end -}}
{{- end -}}

{{/*
Return the path to the CA cert file.
*/}}
{{- define "redis.tlsCACert" -}}
{{- if (include "redis.createTlsSecret" . ) -}}
    {{- printf "/opt/bitnami/redis/certs/%s" "ca.crt" -}}
{{- else }}
    {{- ternary "" (printf "/opt/bitnami/redis/certs/%s" .Values.tls.certCAFilename) (empty .Values.tls.certCAFilename) }}
{{- end -}}
{{- end -}}

{{/*
Return the path to the DH params file.
*/}}
{{- define "redis.tlsDHParams" -}}
{{- if .Values.tls.dhParamsFilename -}}
{{- printf "/opt/bitnami/redis/certs/%s" .Values.tls.dhParamsFilename -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the shared service account to use
*/}}
{{- define "redis.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the master service account to use
*/}}
{{- define "redis.masterServiceAccountName" -}}
{{- if .Values.master.serviceAccount.create -}}
    {{ default (printf "%s-master" (include "common.names.fullname" .)) .Values.master.serviceAccount.name }}
{{- else -}}
    {{- if .Values.serviceAccount.create -}}
        {{ template "redis.serviceAccountName" . }}
    {{- else -}}
        {{ default "default" .Values.master.serviceAccount.name }}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create the name of the replicas service account to use
*/}}
{{- define "redis.replicaServiceAccountName" -}}
{{- if .Values.replica.serviceAccount.create -}}
    {{ default (printf "%s-replica" (include "common.names.fullname" .)) .Values.replica.serviceAccount.name }}
{{- else -}}
    {{- if .Values.serviceAccount.create -}}
        {{ template "redis.serviceAccountName" . }}
    {{- else -}}
        {{ default "default" .Values.replica.serviceAccount.name }}
    {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Return the configuration configmap name
*/}}
{{- define "redis.configmapName" -}}
{{- if .Values.existingConfigmap -}}
    {{- printf "%s" (tpl .Values.existingConfigmap $) -}}
{{- else -}}
    {{- printf "%s-configuration" (include "common.names.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return true if a configmap object should be created
*/}}
{{- define "redis.createConfigmap" -}}
{{- if empty .Values.existingConfigmap }}
    {{- true -}}
{{- end -}}
{{- end -}}

{{/*
Get the password secret.
*/}}
{{- define "redis.secretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- printf "%s" (tpl .Values.auth.existingSecret $) -}}
{{- else -}}
{{- printf "%s" (include "common.names.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Get the password key to be retrieved from Redis&reg; secret.
*/}}
{{- define "redis.secretPasswordKey" -}}
{{- if and .Values.auth.existingSecret .Values.auth.existingSecretPasswordKey -}}
{{- printf "%s" (tpl .Values.auth.existingSecretPasswordKey $) -}}
{{- else -}}
{{- printf "redis-password" -}}
{{- end -}}
{{- end -}}

{{/*
Return Redis&reg; password
*/}}
{{- define "redis.password" -}}
{{- if or .Values.auth.enabled .Values.global.redis.password -}}
    {{- $password_tmp := include "common.secrets.passwords.manage" (dict "secret" (include "redis.secretName" .) "key" (include "redis.secretPasswordKey" .) "providedValues" (list "global.redis.password" "auth.password") "length" 10 "skipB64enc" true "skipQuote" true "honorProvidedValues" true "context" $) -}}
    {{- $_ := set .Values.global.redis "password" $password_tmp -}}
    {{- .Values.global.redis.password -}}
{{- end }}
{{- end }}

{{/*
Returns the secret value if found or an empty string otherwise
Used for fetching Redis ACL user passwords from Kubernetes Secrets
*/}}
{{- define "common.secrets.get" -}}
{{- $secret := (lookup "v1" "Secret" .context.Release.Namespace .secret) -}}
{{- if and $secret (index $secret.data .key) -}}
    {{- index $secret.data .key | b64dec -}}
{{- else -}}
    {{- "" -}}
{{- end }}
{{- end }}

{{/* Check if there are rolling tags in the images */}}
{{- define "redis.checkRollingTags" -}}
{{- $ecrConfig := include "redis.ecrConfig" . | fromYaml -}}
{{- if and $ecrConfig $ecrConfig.registry $ecrConfig.repository -}}
{{- $imageRoot := dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.image.tag | default "") -}}
{{- $sentinelImageRoot := dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.sentinel.image.tag | default "") -}}
{{- $metricsImageRoot := dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.metrics.image.tag | default "") -}}
{{- include "common.warnings.rollingTag" $imageRoot }}
{{- include "common.warnings.rollingTag" $sentinelImageRoot }}
{{- include "common.warnings.rollingTag" $metricsImageRoot }}
{{- else -}}
{{- include "common.warnings.rollingTag" .Values.image }}
{{- include "common.warnings.rollingTag" .Values.sentinel.image }}
{{- include "common.warnings.rollingTag" .Values.metrics.image }}
{{- end -}}
{{- end -}}

{{/*
Compile all warnings into a single message, and call fail.
*/}}
{{- define "redis.validateValues" -}}
{{- $messages := list -}}
{{- $messages := append $messages (include "redis.validateValues.architecture" .) -}}
{{- $messages := append $messages (include "redis.validateValues.podSecurityPolicy.create" .) -}}
{{- $messages := append $messages (include "redis.validateValues.tls" .) -}}
{{- $messages := append $messages (include "redis.validateValues.createMaster" .) -}}
{{- $messages := without $messages "" -}}
{{- $message := join "\n" $messages -}}

{{- if $message -}}
{{-   printf "\nVALUES VALIDATION:\n%s" $message | fail -}}
{{- end -}}
{{- end -}}

{{/* Validate values of Redis&reg; - must provide a valid architecture */}}
{{- define "redis.validateValues.architecture" -}}
{{- if and (ne .Values.architecture "standalone") (ne .Values.architecture "replication") -}}
redis: architecture
    Invalid architecture selected. Valid values are "standalone" and
    "replication". Please set a valid architecture (--set architecture="xxxx")
{{- end -}}
{{- if and .Values.sentinel.enabled (not (eq .Values.architecture "replication")) }}
redis: architecture
    Using redis sentinel on standalone mode is not supported.
    To deploy redis sentinel, please select the "replication" mode
    (--set "architecture=replication,sentinel.enabled=true")
{{- end -}}
{{- end -}}

{{/* Validate values of Redis&reg; - PodSecurityPolicy create */}}
{{- define "redis.validateValues.podSecurityPolicy.create" -}}
{{- if and .Values.podSecurityPolicy.create (not .Values.podSecurityPolicy.enabled) }}
redis: podSecurityPolicy.create
    In order to create PodSecurityPolicy, you also need to enable
    podSecurityPolicy.enabled field
{{- end -}}
{{- end -}}

{{/* Validate values of Redis&reg; - TLS enabled */}}
{{- define "redis.validateValues.tls" -}}
{{- if and .Values.tls.enabled (not .Values.tls.autoGenerated) (not .Values.tls.existingSecret) (not .Values.tls.certificatesSecret) }}
redis: tls.enabled
    In order to enable TLS, you also need to provide
    an existing secret containing the TLS certificates or
    enable auto-generated certificates.
{{- end -}}
{{- end -}}

{{/* Validate values of Redis&reg; - master service enabled */}}
{{- define "redis.validateValues.createMaster" -}}
{{- if and (or .Values.sentinel.masterService.enabled .Values.sentinel.service.createMaster) (or (not .Values.rbac.create) (not .Values.replica.automountServiceAccountToken) (not .Values.serviceAccount.create)) }}
redis: sentinel.masterService.enabled
    In order to redirect requests only to the master pod via the service, you also need to
    create rbac and serviceAccount. In addition, you need to enable
    replica.automountServiceAccountToken.
{{- end -}}
{{- end -}}

{{/* Define the suffix utilized for external-dns */}}
{{- define "redis.externalDNS.suffix" -}}
{{ printf "%s.%s" (include "common.names.fullname" .) .Values.useExternalDNS.suffix }}
{{- end -}}

{{/* Compile all annotations utilized for external-dns */}}
{{- define "redis.externalDNS.annotations" -}}
{{- if and .Values.useExternalDNS.enabled .Values.useExternalDNS.annotationKey }}
{{ .Values.useExternalDNS.annotationKey }}hostname: {{ include "redis.externalDNS.suffix" . }}
{{- range $key, $val := .Values.useExternalDNS.additionalAnnotations }}
{{ $.Values.useExternalDNS.annotationKey }}{{ $key }}: {{ $val | quote }}
{{- end }}
{{- end }}
{{- end }}
