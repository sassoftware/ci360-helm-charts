from datetime import datetime, timedelta, timezone

from airflow.sdk import dag, task
from maicompute.tasks.blob_cleanup import cleanup_stale_blob_lifecycle_policies


@dag(
    dag_id="mai_blob_cleanup_lifecycle_policy_cleanup",
    description="Remove stale blob lifecycle-policy rules after their prefixes are empty",
    schedule="0 3 * * *",
    start_date=datetime(2026, 3, 31, tzinfo=timezone.utc),
    catchup=False,
    max_active_runs=1,
    is_paused_upon_creation=False,
    default_args={
        "queue": "high-priority",
        "retries": 1,
        "retry_delay": timedelta(minutes=5),
    },
    tags=["Marketing AI Internal Blob Cleanup", "maintenance"],
)
def blob_cleanup_lifecycle_policy_cleanup_dag():
    @task(task_id="cleanup_stale_blob_lifecycle_policies")
    def cleanup_policy_rules():
        return cleanup_stale_blob_lifecycle_policies()

    cleanup_policy_rules()


dag = blob_cleanup_lifecycle_policy_cleanup_dag()
