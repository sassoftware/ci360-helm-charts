# Feature Flags ConfigMap Handoff

## Resource

The shared ConfigMap is named `mai-feature-flags-snapshot` and contains the key
`features.json`.

The resource is defined by the `ci360-satellite` subchart, not by the umbrella
`local-agent` templates directly:

- Template: `../charts/service/templates/configmap-feature-flags.yaml`
- Values: `../charts/service/values.yaml`
- Umbrella dependency: `Chart.yaml` -> `ci360-satellite` -> `../charts/service`

The ConfigMap is created only when both settings are enabled:

```yaml
featureFlags:
  enabled: true
  createConfigMap: true
```

The template uses Helm `lookup` to preserve the existing `features.json` value
when the ConfigMap already exists. If no existing value is found, it initializes
the key with `{}`. With `keepOnDelete: true`, Helm adds
`helm.sh/resource-policy: keep`, so deleting the release does not delete the
ConfigMap.

## Mounting Workloads

### MAI Proxy

The `ci360-satellite` proxy Deployment mounts the ConfigMap at:

```text
/tmp/feature-flags/features.json
```

The mount is configured in:

- `../charts/service/templates/deployment-proxy.yaml`

The proxy also receives these environment variables:

- `MAI_LOCAL_AGENT_FEATURE_FLAGS_PATH`
- `MAI_FEATURE_FLAGS_CONFIGMAP_NAME`
- `MAI_FEATURE_FLAGS_CONFIGMAP_KEY`
- `MAI_FEATURE_FLAGS_CONFIGMAP_UPDATE_ENABLED`
- `MAI_FEATURE_FLAGS_CONFIGMAP_MAX_RETRIES`
- `POD_NAMESPACE`

### MAI Orchestra

The `ci360-satellite` orchestra Deployment mounts the same ConfigMap at
`/tmp/feature-flags`. Its application reads the feature snapshot through
`MAI_LOCAL_AGENT_FEATURE_FLAGS_PATH`.

The mount is configured in:

- `../charts/service/templates/deployment-orchestra.yaml`

### Airflow Workers

The original umbrella chart configures Airflow workers directly in:

- `values.yaml` under `airflow.workers`

The workers mount `mai-feature-flags-snapshot` at `/tmp/feature-flags` and read
`features.json` from that directory. This is independent of the proxy and
orchestra Deployment templates, but it uses the same ConfigMap name.

The current chart does not configure this mount for the Airflow scheduler,
webserver, API server, PostgreSQL, Redis, or OTEL Collector.

## Runtime Writer

The ConfigMap is not created by the proxy application at runtime. Helm creates
the Kubernetes resource.

The MAI Proxy application can update the existing ConfigMap using the Kubernetes
API through:

- `ci360-analytic-mai/projects/maiproxy/maiproxy/ws_client/feature_flags_configmap_updater.py`

The updater reads the ConfigMap, compares the serialized payload, and replaces
the `features.json` key when the snapshot changes. A missing ConfigMap produces
a runtime error explaining that it must be created by Helm or pre-created.

## RBAC

When the feature flag writer is enabled, the `ci360-satellite` subchart creates:

- `role-feature-flags-configmap-writer.yaml`
- `rolebinding-feature-flags-configmap-writer.yaml`

The role grants the `ci360-satellite` service account these permissions on this
specific ConfigMap:

```text
get, update, patch
```

The role does not grant create or delete permission. Therefore, the resource
must exist before the MAI Proxy updater can write to it.

## Startup Dependency

With feature flags enabled, MAI Proxy, MAI Orchestra, and the original
Airflow workers all reference the ConfigMap as a Kubernetes volume. If the
ConfigMap is absent, their Pods cannot start successfully and typically remain
in `ContainerCreating` or report `CreateContainerConfigError`.

This is not a runtime dependency on the proxy process. The workloads can start
independently once the ConfigMap already exists.

The ConfigMap can exist because:

1. Helm created it through the `ci360-satellite` template.
2. A previous Helm release retained it due to `keepOnDelete: true`.
3. An operator or another deployment pre-created it.

Alternatively, feature flags can be disabled so the chart omits the relevant
mounts and environment variables.

## local-agent-v2 Note

In the supplied `local-agent-v2/values.yaml`, the Airflow worker feature flag
volume and environment configuration is commented out. Those commented lines
do not create a mount. The active v2 proxy and orchestrator behavior should be
checked in their respective subchart templates and values before assuming that
they use the original `ci360-satellite` ConfigMap flow.
