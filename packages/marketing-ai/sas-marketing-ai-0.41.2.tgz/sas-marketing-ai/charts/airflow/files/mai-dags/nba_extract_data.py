from datetime import timedelta
from airflow.sdk import DAG, task, get_current_context
from mai_global import logger

from maicompute.recipes.nba.functions import (
    validate_data_connection,
    extract_nba_data,
)

default_args = {
    'retries': 3,
    'retry_delay': timedelta(seconds=20),
    'queue': 'high-priority'
}

with DAG(
    dag_id="nba_data_extract",
    description="Validate connection and extract data for NBA data source like actions and response types",
    catchup=False,
    tags=['Marketing AI Internal NBA data extraction Workflows'],
    schedule=None,
    default_args=default_args,
    max_active_runs=1,  # prevent concurrent runs of the same config
) as dag:

    @task
    def get_user_option_from_conf() -> dict:
        """Get UserOption JSON supplied through dag_run.conf."""
        context = get_current_context()
        dag_run = context["dag_run"]

        if not dag_run or not dag_run.conf:
            raise ValueError("UserOption JSON was not supplied in dag_run.conf")

        user_options = dag_run.conf
        if not user_options:
            raise ValueError("Missing required user_options in dag_run.conf")

        logger.info(f"NBA data extraction requested.")
        return user_options  # return only the dict, extract run_id downstream

    @task
    def validate_connection_task(user_options: dict):
        """Validate the source connection."""
        af_run_number = user_options["recipe"]["execution_id"]
        connections = user_options["connections"]
        # Handle both list and dict
        if isinstance(connections, list):
            connection_id = connections[0]["id"]
        else:
            connection_id = connections["id"]

        logger.info(f"connection_id: {connection_id}, af_run_number: {af_run_number}")

        return validate_data_connection(
            user_options=user_options,
            af_run_number=af_run_number,
            input_parameters={"connection_id": connection_id},
        )

    @task
    def extract_data_task(user_options: dict):
        """Extract data after successful connection validation."""
        af_run_number = user_options["recipe"]["execution_id"]
        datasource = user_options["data_sources"]
         # Handle both list and dict
        if isinstance(datasource, list):
            ds_id = datasource[0]["datasource_id"]
        else:
            ds_id = datasource["datasource_id"]
        logger.info(f"datasource_id: {ds_id}, af_run_number: {af_run_number}")

        return extract_nba_data(
            user_options=user_options,
            af_run_number=af_run_number,
            input_parameters={"datasource_id": ds_id},
        )

    # Flow
    user_options = get_user_option_from_conf()
    validation = validate_connection_task(user_options=user_options)
    validation >> extract_data_task(user_options=user_options)
