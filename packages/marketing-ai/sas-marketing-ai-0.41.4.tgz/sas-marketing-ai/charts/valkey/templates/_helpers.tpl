{{/*
Expand the name of the chart.
*/}}
{{- define "valkey.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "valkey.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "valkey.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "valkey.labels" -}}
helm.sh/chart: {{ include "valkey.chart" . }}
{{ include "valkey.selectorLabels" . }}
{{- if or .Values.image.tag .Chart.AppVersion }}
app.kubernetes.io/version: {{ mustRegexReplaceAllLiteral "@sha.*" .Values.image.tag "" | default .Chart.AppVersion | trunc 63 | trimSuffix "-" | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{- toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "valkey.selectorLabels" -}}
app.kubernetes.io/name: {{ include "valkey.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "valkey.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "valkey.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Returns the Valkey container image
*/}}
{{- define "valkey.image" -}}
{{- $ecrConfig := include "valkey.ecrConfig" . | fromYaml -}}
{{- $image := dict "registry" .Values.image.registry "repository" .Values.image.repository "tag" (.Values.image.tag | default .Chart.AppVersion) -}}
{{- if $ecrConfig.registry -}}
{{- $image = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.image.tag | default .Chart.AppVersion) -}}
{{- else if not .Values.image.repository -}}
{{- $image = dict "registry" (.Values.image.registry | default "docker.io") "repository" "valkey/valkey" "tag" (.Values.image.tag | default .Chart.AppVersion) -}}
{{- end -}}
{{- include "common.image" (dict "image" $image "global" .Values.global) }}
{{- end -}}

{{/*
Resolve the image-manager ECR registry and repository from global.ExternalGatewayHost.
*/}}
{{- define "valkey.ecrConfig" -}}
{{- $fullPathMap := dict
  "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
  "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
  "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
  "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
  "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $fullPath := get $fullPathMap (.Values.global.ExternalGatewayHost | default "") -}}
{{- if $fullPath -}}
{{- $parts := splitList "/" $fullPath -}}
{{- dict "registry" (index $parts 0) "repository" (printf "%s/%s" (index $parts 1) (index $parts 2)) | toYaml -}}
{{- else -}}
{{- dict "registry" "" "repository" "" | toYaml -}}
{{- end -}}
{{- end -}}

{{/*
Returns the Valkey exporter container image
*/}}
{{- define "valkey.metrics.exporter.image" -}}
{{- include "common.image" (dict "image" .Values.metrics.exporter.image "global" .Values.global) }}
{{- end -}}

{{/*
Returns the Valkey Sentinel container image
*/}}
{{- define "valkey.sentinel.image" -}}
{{- $ecrConfig := include "valkey.ecrConfig" . | fromYaml -}}
{{- $image := .Values.sentinel.image -}}
{{- if $ecrConfig.registry -}}
{{- $image = dict "registry" $ecrConfig.registry "repository" $ecrConfig.repository "tag" (.Values.sentinel.image.tag | default .Values.image.tag | default .Chart.AppVersion) "pullPolicy" .Values.sentinel.image.pullPolicy -}}
{{- else if not .Values.sentinel.image.repository -}}
{{- $image = dict "registry" (.Values.sentinel.image.registry | default "docker.io") "repository" "valkey/valkey" "tag" (.Values.sentinel.image.tag | default .Values.image.tag | default .Chart.AppVersion) "pullPolicy" .Values.sentinel.image.pullPolicy -}}
{{- end -}}
{{- include "common.image" (dict "image" $image "global" .Values.global) }}
{{- end -}}

{{/*
The common image function that renders the container image
*/}}
{{- define "common.image" -}}
{{- $registryName := .image.registry }}
{{- $repositoryName := .image.repository }}
{{- $tag := .image.tag }}
{{- if .global }}
  {{- if .global.imageRegistry }}
    {{- $registryName = .global.imageRegistry }}
  {{- end }}
{{- end }}
{{- if $registryName }}
{{- printf "%s/%s:%s" $registryName $repositoryName $tag }}
{{- else }}
{{- printf "%s:%s" $repositoryName $tag }}
{{ end }}
{{- end -}}

{{/*
Returns the Valkey image pull secrets
*/}}
{{- define "valkey.imagePullSecrets" -}}
{{- $pullSecrets := list }}
{{- if .Values.global }}
  {{- range .Values.global.imagePullSecrets -}}
    {{- $pullSecrets = append $pullSecrets . -}}
  {{- end -}}
{{- end -}}
{{- range .Values.imagePullSecrets -}}
    {{- $pullSecrets = append $pullSecrets . -}}
{{- end -}}
{{- if (not (empty $pullSecrets)) }}
imagePullSecrets:
{{- range $pullSecrets }}
- name: {{ . }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Check if there are any users with inline passwords
*/}}
{{- define "valkey.hasInlinePasswords" -}}
{{- $hasInlinePasswords := false -}}
{{- range $username, $user := .Values.auth.aclUsers -}}
  {{- if $user.password -}}
    {{- $hasInlinePasswords = true -}}
  {{- end -}}
{{- end -}}
{{- $hasInlinePasswords -}}
{{- end -}}

{{/*
Validate auth configuration
*/}}
{{- define "valkey.validateAuthConfig" -}}
{{- if .Values.auth.enabled }}
  {{- if not (or .Values.auth.aclUsers .Values.auth.aclConfig) }}
    {{- fail "auth.enabled is true but no authentication method is configured. Please provide auth.aclUsers or auth.aclConfig" }}
  {{- end }}
  {{- if .Values.auth.aclUsers }}
    {{- $hasUsersExistingSecret := .Values.auth.usersExistingSecret }}
    {{- if not (hasKey .Values.auth.aclUsers "default") }}
      {{- fail "The 'default' user must be defined in auth.aclUsers when authentication is enabled. Without it, anyone can access the database without credentials." }}
    {{- end }}
    {{- range $username, $user := .Values.auth.aclUsers }}
      {{- if not $user.permissions }}
        {{- fail (printf "User '%s' in auth.aclUsers must have a 'permissions' field" $username) }}
      {{- end }}
      {{- if not (or $user.password $hasUsersExistingSecret) }}
        {{- fail (printf "User '%s' must have either 'password' field or auth.usersExistingSecret must be set" $username) }}
      {{- end }}
      {{- if and $user.passwordKey (not $hasUsersExistingSecret) }}
        {{- fail (printf "User '%s' has passwordKey but auth.usersExistingSecret is not set" $username) }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end -}}

{{/*
Headless service name for replication
*/}}
{{- define "valkey.headlessServiceName" -}}
{{ include "valkey.fullname" . }}-headless
{{- end -}}

{{/*
Validate replica persistence configuration
*/}}
{{- define "valkey.validateReplicaPersistence" -}}
{{- if .Values.replica.enabled }}
  {{- if not .Values.replica.persistence.size }}
    {{- fail "Replica mode requires persistent storage. Please set replica.persistence.size (e.g., '5Gi')" }}
  {{- end }}
{{- end }}
{{- end -}}

{{/*
Validate replica authentication configuration
*/}}
{{- define "valkey.validateReplicaAuth" -}}
{{- if and .Values.replica.enabled .Values.auth.enabled }}
  {{- if not (hasKey .Values.auth.aclUsers .Values.replica.replicationUser) }}
    {{- fail (printf "Replication user '%s' (replica.replicationUser) must be defined in auth.aclUsers. The chart requires this to retrieve the password for replica authentication." .Values.replica.replicationUser) }}
  {{- end }}
{{- end }}
{{- end -}}

{{/*
Render the Valkey server container health probes (startupProbe, livenessProbe,
readinessProbe). Each probe is gated on its own `enabled` flag. When a probe's
`customProbe` map is set it replaces the default handler and timing entirely;
otherwise the default valkey-cli ping exec handler (TLS-aware) is emitted with
whichever timing fields are set on that probe. The command is built as an
argument list and invokes valkey-cli directly (no shell), with the TLS flags
appended only when `tls.enabled` is set. Returns nothing when no probe is
enabled, so callers should guard with `with`.
*/}}
{{- define "valkey.healthProbes" -}}
{{- $cmd := list "valkey-cli" -}}
{{- if $.Values.tls.enabled -}}
{{- $cmd = concat $cmd (list "--cacert" (printf "/tls/%s" $.Values.tls.caPublicKey) "--tls") -}}
{{- end -}}
{{- $cmd = append $cmd "ping" -}}
{{- $probes := dict -}}
{{- range $name := (list "startupProbe" "livenessProbe" "readinessProbe") -}}
{{- $probe := index $.Values $name -}}
{{- if $probe -}}
{{- if $probe.enabled -}}
{{- if $probe.customProbe -}}
{{- $probes = set $probes $name $probe.customProbe -}}
{{- else -}}
{{- $rendered := dict "exec" (dict "command" $cmd) -}}
{{- range $field := (list "initialDelaySeconds" "periodSeconds" "timeoutSeconds" "failureThreshold" "successThreshold") -}}
{{- if hasKey $probe $field -}}{{- $rendered = set $rendered $field (index $probe $field) -}}{{- end -}}
{{- end -}}
{{- $probes = set $probes $name $rendered -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $probes -}}
{{- toYaml $probes -}}
{{- end -}}
{{- end -}}

