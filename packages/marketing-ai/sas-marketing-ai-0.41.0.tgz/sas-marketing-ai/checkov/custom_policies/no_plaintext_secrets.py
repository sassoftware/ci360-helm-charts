
from __future__ import annotations

import re

from detect_secrets.plugins.base import RegexBasedDetector


class NoPlaintextSecrets(RegexBasedDetector):
    """Flag hardcoded credentials assigned to secret-ish keys in Helm values files.

    Registered into Checkov's *secrets* framework via --external-checks-dir, so it
    runs under `checkov --framework secrets --enable-secret-scan-all-files`.

    The previous BaseYamlCheck implementation never fired: Checkov's yaml_doc
    runner is only wired to CI-config frameworks (GitHub Actions, GitLab CI, ...)
    and is never invoked for plain Helm values files.
    """

    check_id = "CKV_SECRET_100"
    secret_type = "Hardcoded secret in Helm values"

    # Key fragments that indicate the value is a credential.
    _KEY = (
        r"(?:pass(?:word|wd)?|pwd"
        r"|secret[_-]?key|secretkey|secret"
        r"|api[_-]?key|access[_-]?key|private[_-]?key|client[_-]?secret"
        r"|conn(?:ection)?[_-]?string"
        r"|credentials?|token"
        r"|key)"
    )

    # Keys that are legitimate *references* to a secret, not the secret itself.
    _ALLOWED = (
        r"(?!existing[_-]?secret\b)"
        r"(?!secret[_-]?key[_-]?ref\b)"
        r"(?!secret[_-]?name\b)"
        r"(?!value[_-]?from\b)"
        r"(?!external[_-]?secret\b)"
        r"(?!key[_-]?path\b)"
        r"(?!key[_-]?ref\b)"
    )

    # Values that are placeholders / indirection, not real secrets.
    _NOT_A_SECRET = (
        r"(?!\{\{)"          # Helm template    {{ .Values.foo }}
        r"(?!\$\{)"          # env substitution ${FOO}
        r"(?!\$\()"          # $(FOO)
        r"(?!<)"             # <replace-me>
        r"(?!null\b)"
        r"(?!true\b)(?!false\b)"
        r"(?!\*)"            # YAML alias  *anchor
        r"(?!&)"             # YAML anchor &anchor
    )

    denylist = [
        re.compile(
            r"^\s*"                       # start of a YAML mapping line
            r"[\"']?"                     # optional quoted key
            + _ALLOWED
            + r"[A-Za-z0-9_\-]*"          # key prefix, e.g. postgres<Password>
            + _KEY
            + r"[A-Za-z0-9_\-]*"          # key suffix
            r"[\"']?\s*:\s*"              # the colon
            r"[\"']?"                     # optional quoted value
            + _NOT_A_SECRET
            + r"[^\s\"'#]{6,}",           # the actual value: >=6 non-blank chars
            re.IGNORECASE | re.MULTILINE,
        ),
    ]
