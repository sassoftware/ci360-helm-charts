# GCP Infrastructure Requirements for Local Agent

Review the information in the following sections to set up your Google Kubernetes Engine (GKE) environment for the local agent.

1. [GKE Cluster Requirements](#1-gke-cluster-requirements)
2. [Configure Container Storage](#2-configure-container-storage)
3. [Identity and Access Control (Workload Identity)](#3-identity-and-access-control-workload-identity)
4. [Object Lifecycle Cleanup Configuration](#4-object-lifecycle-cleanup-configuration)
5. [Networking - Cloud NAT](#5-networking---cloud-nat)
6. [Additional Components](#6-additional-components)
7. [Monitoring Agent](#7-monitoring-agent)

## 1. GKE Cluster Requirements

Make sure that the Kubernetes cluster meets these requirements:

| Item | Requirement / Recommendation |
|------|------------------------------|
| Kubernetes Version | >= 1.30 recommended |
| Cloud Provider | Google Cloud (GKE) |
| Cluster Mode | Standard cluster (do **not** use Autopilot) |
| Workload Identity | Enabled on the cluster and on each node pool (IRSA equivalent) |
| Node Type | Compute Engine nodes with adequate CPU/RAM (for example, `e2-standard-4`) |
| Persistent Disk CSI Driver | Must be enabled in the cluster (`pd.csi.storage.gke.io`) |
| Filestore CSI Driver | Must be enabled in the cluster (`filestore.csi.storage.gke.io`) |
| StorageClass (default) | `standard-rwo` - ReadWriteOnce, provisioned by the Persistent Disk CSI Driver |
| StorageClass for DAGs | `standard-rwx` - ReadWriteMany, provisioned by the Filestore CSI Driver |

### Create StorageClasses

Create the required StorageClasses for persistent volume management. Apply the StorageClass definitions using `kubectl`:

```sh
kubectl apply -f storage-classes-immediate.yaml
```

Or, create the StorageClasses manually:

**ReadWriteOnce (RWO) StorageClass** for general persistent storage:

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: standard-rwo
provisioner: pd.csi.storage.gke.io
volumeBindingMode: Immediate
parameters:
  type: pd-standard
allowVolumeExpansion: true
```

**ReadWriteMany (RWX) StorageClass** for shared storage (DAGs and logs):

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: standard-rwx
provisioner: filestore.csi.storage.gke.io
volumeBindingMode: Immediate
parameters:
  tier: standard
  network: default
allowVolumeExpansion: true
```

Verify the StorageClasses are created:

```sh
kubectl get storageclass
```

### Cluster Guidelines

Follow these guidelines when you set up the cluster:

1. Set the default size of the cluster based on the size of your data volumes.
2. Create a dedicated node pool for the local agent workloads and record its name with private nodes enabled. We'd setup Cloud NAT gateway to communicate with external world. The node pool name is used by the `cloud.google.com/gke-nodepool` node selector in `values-gcp.yaml`.

   Use this information to configure the node pool:

   | Setting | Value |
   |---------|-------|
   | Minimum node count | 8 |
   | Machine type (recommended) | `e2-standard-4` |
   | Taints | None (default) |
   | Labels | Optional (for scheduling) |
   | Zones | Optional (depends on topology constraints) |

3. Configure one or more storage volumes that contain your data. Use Cloud Storage to create a bucket to store the data (for example, `ci360-mai-la-data`).

## 2. Configure Container Storage

This storage location is the base location that is used by the local agent. The application creates other subfolders as needed inside this base location.

1. Create a Cloud Storage bucket. Name the bucket using this pattern:

   ```text
   ci360-mai-<env>-data
   ```

   Example:

   ```text
   ci360-mai-la-data
   ```

2. Create the following prefixes (folders) in the bucket:

   | Prefix | Purpose |
   |--------|---------|
   | `mai` | Application data |
   | `mai/logs` | Airflow remote log storage |

   The Airflow remote log folder is specified as a `gs://` URI in `values-gcp.yaml`.

   Example:

   ```text
   gs://ci360-mai-la-data/mai/logs
   ```

3. (Recommended) Enable object versioning and uniform bucket-level access on the bucket.

## 3. Identity and Access Control (Workload Identity)

Workload Identity allows Kubernetes pods to securely access Google Cloud resources by binding a Kubernetes service account to an IAM service account. This enables access without requiring that you hardcode service account keys.

### Workload Identity Setup Steps

Configure these parts, in order:

1. Enable Workload Identity on the cluster and on each node pool.
2. Create an IAM service account for the application, for example `mai-local-agent@<project-id>.iam.gserviceaccount.com`.
3. Grant the IAM service account the required roles on the bucket and project.
4. Bind the IAM service account to the Kubernetes service accounts that are used by the application by granting the `roles/iam.workloadIdentityUser` role.
5. Annotate the Kubernetes service accounts with `iam.gke.io/gcp-service-account: <iam-service-account-email>`. The Helm chart applies this annotation to the Airflow API server, workers, triggerer, and the `ci360-satellite` service account when the value is set in `values-gcp.yaml`.

### Create the IAM Service Account and Grant Roles

```sh
export PROJECT_ID=<project-id>
export GSA=mai-local-agent
export BUCKET=ci360-mai-la-data
export NAMESPACE=<namespace>

gcloud iam service-accounts create $GSA --project $PROJECT_ID

gcloud storage buckets add-iam-policy-binding gs://$BUCKET \
  --member="serviceAccount:$GSA@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.objectAdmin"
```

### Bind the Kubernetes Service Accounts

Repeat the binding for each Kubernetes service account that is used by the deployment, such as `ci360-analytic-mai` and the Airflow service accounts:

```sh
gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai]"
```

### Bind Additional Service Accounts After Helm Deployment

After deploying the Helm chart, bind the following Kubernetes service accounts to the IAM service account. Run these commands for each service account:

```sh
export GSA=mai-local-agent
export PROJECT_ID=<project-id>
export NAMESPACE=<namespace>

# Airflow Components
gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-api-server]"

gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-dag-processor]"

gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-scheduler]"

# Airflow Workers
gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-worker]"

gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-worker-high-priority]"

gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-airflow-worker-high-memory]"

# CI360 Satellite Components
gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-ci360-satellite-orchestra]"

gcloud iam service-accounts add-iam-policy-binding \
  $GSA@$PROJECT_ID.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:$PROJECT_ID.svc.id.goog[$NAMESPACE/ci360-analytic-mai-ci360-satellite-proxy]"
```

**Note:** Replace `<project-id>` and `<namespace>` with your actual GCP project ID and Kubernetes namespace. These bindings enable all deployed components to access GCP resources using

### Capture the Service Account Email and Project ID

After the IAM service account is created, record the service account email and the project ID. Both values are required in the deployment configuration (`gcpServiceAccount` and `projectId` in `values-gcp.yaml`).

Example:

```text
mai-local-agent@sas-01000a9f-3ce7-4a34-91bb-f6.iam.gserviceaccount.com
```

## 4. Object Lifecycle Cleanup Configuration

MAI can apply Cloud Storage lifecycle rules to eventually remove Recipe and Project artifacts after the Recipe or Project is deleted.

Lifecycle configuration is a bucket-level resource. Grant the IAM service account that is used by MAI permission to read and update the bucket lifecycle policy at bucket scope. The `roles/storage.admin` role at bucket scope satisfies this requirement. Object-level or prefix scope is not enough for lifecycle rule management.

```sh
gcloud storage buckets add-iam-policy-binding gs://$BUCKET \
  --member="serviceAccount:$GSA@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.admin"
```

## 5. Networking - Cloud NAT

Configure Cloud NAT with a static external IP address for outbound traffic. Cloud NAT enables communication between data sources that might exist in a different cluster or cloud provider.

Complete these steps:

1. In the Google Cloud Console, navigate to **Network services > Cloud NAT**.
2. Select **Create Cloud NAT gateway**.
3. Select the VPC network and region associated with your GKE cluster.
4. Create or select a Cloud Router for the VPC and region.
5. Reserve and assign a static external IP address to the NAT gateway, and configure it for the GKE subnet.
6. Verify outbound connectivity from the GKE cluster nodes/pods.

## 6. Additional Components

### KEDA

KEDA (Kubernetes Event-Driven Autoscaling) enables event-driven or auto-scaled workloads, such as Airflow workers.

1. Install KEDA:

```sh
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda --namespace keda --create-namespace
```

2. Verify the installation:

```sh
kubectl get pods -n keda
```

### ServiceMonitor CRD

1. Verify that the ServiceMonitor CRD exists:

```sh
kubectl get crd servicemonitors.monitoring.coreos.com
```

2. If it does not exist, deploy it:

```sh
kubectl apply -f https://raw.githubusercontent.com/prometheus-operator/prometheus-operator/main/example/prometheus-operator-crd/monitoring.coreos.com_servicemonitors.yaml
```

### Artifact Access

The deployment pulls images through the external gateway host that is configured in `values-gcp.yaml` (`global.ExternalGatewayHost`). Make sure that the cluster nodes can reach this host and that the registry credentials secret (`ci360-api-credentials`) exists in the deployment namespace.

## 7. Monitoring Agent

The cluster must have a monitoring and observability solution enabled. Existing platforms such as Datadog, Dynatrace, New Relic, or an equivalent enterprise monitoring solution are acceptable. If no monitoring solution is currently deployed, enable Google Cloud native monitoring by using Cloud Operations for GKE (Cloud Monitoring and Cloud Logging) and Google Cloud Managed Service for Prometheus. This provides the required observability, metrics, and logging capabilities before implementation.
