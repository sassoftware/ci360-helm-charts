# Local-agent

## Mandatory Step for Releasing a new version of 'local-agent' chart(before raising a PR to main branch)
- Open the chart.yaml in local-agent folder and increment the version under dependencies
- Reason for above change is because 'local-agent' is an umbrella chart and it has dependency on other charts. So whenever there is a new release of any dependent chart, we need to update the version in chart.yaml of umbrella chart 'local-agent'.

## Steps for installing Umbrella chart 'local-agent'
- Open a terminal in the `local-agent` folder and run the following commands:
  - `helm dependency update`
  - `helm upgrade --install <release-name> . --namespace <your-namespace> --create-namespace --values values.yaml --timeout 15m`
  - Complete the steps mentioned in the `Airflow Configuration` section below.
  - `helm test <release-name> --namespace <your-namespace> --logs --timeout 20m &`
  - `kubectl logs -n <your-namespace> -l job-name=local-agent-test-job -f`
- Here, the release name is `<release-name>`, and the namespace is `<your-namespace>`. Replace `<release-name>` with your desired release name and `<your-namespace>` with the namespace you want to use.

## Steps for configuring 'local-agent' on dev cluster
- Change `serviceAccount` annotations in the `values.yaml` file.
- Update `MAI_INTERNAL_STORAGE_BUCKET` and `global.storageBucket`.

### Airflow Configuration
Follow these steps to configure Airflow for the `local-agent`:

1. **Create a Default Airflow Connection**:
   - Open the Airflow UI from the Airflow API server.
   - Navigate to the **Connections** section.
   - Click on the **Create** button to add a new connection.
   - Fill in the following details:
     - **Connection ID**: `aws_default`
     - **Connection Type**: `Amazon Web Services`
   - Leave other fields as default and click **Save**.

2. **Create an Airflow Variable**:
   - Open the Airflow UI from the Airflow API server.
   - Navigate to the **Admin > Variables** section.
   - Click on the **Create** button to add a new variable.
   - Fill in the following details:
     - **Key**: `partition_config`
     - **Value**:
       ```json
       {
         "partition_extract": 1,
         "partition_size": 100000,
         "partition_summary": 0,
         "use_estimated_size": 0,
         "sample_size": 100,
         "row_size_buffer": 3.0,
         "task_memory_buffer_gb": 1.0,
         "cardinality_factor": 10
       }
       ```
   - Click **Save**.


## Contributing
Maintainers are not currently accepting patches and contributions to this project.

## License

This project is licensed under the [Apache 2.0 License](https://github.com/helm/helm/blob/main/LICENSE).

## Additional Resources
- [Helm Documentation](https://helm.sh/docs/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Airflow Documentation](https://airflow.apache.org/docs/)