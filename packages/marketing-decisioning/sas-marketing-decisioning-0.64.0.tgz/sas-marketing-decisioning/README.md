# Deploying Native Components by Using Public Helm Charts

## Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
  - [1. Create a Kubernetes namespace](#1-create-a-kubernetes-namespace)
  - [2. Configure your database](#2-configure-your-database)
  - [3. Use an existing PostgreSQL database](#3-use-an-existing-postgresql-database)
  - [4. Deploy PostgreSQL by using the Helm chart](#4-deploy-postgresql-by-using-the-helm-chart)
  - [5. Configure PostgreSQL backup](#5-configure-postgresql-backup)
  - [6. Create Kubernetes secrets](#6-create-kubernetes-secrets)
  - [7. Verify Helm installation](#7-verify-helm-installation)
  - [8. Verify network access](#8-verify-network-access)
- [Set up the Helm repository](#set-up-the-helm-repository)
- [Customize and deploy the Helm chart](#customize-and-deploy-the-helm-chart)
- [Deploy the Helm Chart](#deploy-the-helm-chart)
- [Verify the deployment](#verify-the-deployment)
- [Access PostgreSQL database](#access-postgresql-database)
- [Troubleshooting](#troubleshooting)

## Overview
This section provides step-by-step instructions to deploy SAS 360 Marketing Decisioning native components by using public Helm charts in a Kubernetes environment.

The deployment process supports a non-fleet model and uses Helm to simplify installation, configuration, and life cycle management of application components and their dependencies.

The Helm chart enables you to deploy the following components:
- SAS 360 Marketing Decisioning native components
- Supporting PostgreSQL database infrastructure
- Kubernetes secrets and configuration resources
- Persistent storage with optional backup configuration.

The deployment supports the following PostgreSQL configuration options:
- Using an externally managed PostgreSQL database
- Deploying PostgreSQL in the Kubernetes cluster by using CloudNativePG

The deployment process includes the following tasks:
- Prepare the Kubernetes namespace
- Prepare database (external or Helm-managed)
- Create required secrets and manage credentials
- Configure the Helm repository
- Customize the values.yaml file
- Deploy the Helm chart
- Validate deployment
- Configure PostgreSQL connectivity
- Troubleshooting

## Prerequisites
Before you deploy the native components, ensure that the following requirements are met.

#### 1. Create a Kubernetes namespace
A target Kubernetes namespace(for example, testasc) must already exist. All SAS 360 Marketing Decisioning components are deployed into this namespace. If the namespace does not exist, create it.

```bash
kubectl create namespace <namespace>
```

#### 2. Configure your database
Choose one of the following methods for configuring a PostgreSQL database:
- Use an existing PostgreSQL database.
- Deploy a PostgreSQL database by using a Helm chart.

#### 3. Use an existing PostgreSQL database
**⚠️ Important:** Skip this step if you want to use a Helm chart to provision a PostgreSQL database instance.

a) Set up a PostgreSQL database:
- Ensure that a PostgreSQL database is provisioned and reachable from the Kubernetes cluster.
- You must provide the following details:
  - host (for example, postgres-service)
  - database name
  - user name and password
  - port (default: 5432)
- The database must allow connections from deployed services.

b) Initialize the database. This is a one-time task.

**⚠️ Important:** Perform this task only once. Complete it before you deploy the Helm chart.

Connect to the PostgreSQL database
```bash
psql -h <host> -U <username> -d <database>
```
Create the schema. The schema name must be contactresponse.
```sql
CREATE SCHEMA IF NOT EXISTS contactresponse;
```
Create the required tables.

Use the DDL file `CI360_ContactHistory_DDL_Scripts.sql`, available in the `tools/marketing-decisioning` folder of the `ci360-helm-charts` repository.

Verify that the tables are created:

```sql
SELECT * FROM contactresponse.subject_contact LIMIT 10;
```

**Note:** Ensure that the database schema matches `search_path=contactresponse`. The database user must have Create, Insert, Select, Update, and Delete permissions.

#### 4. Deploy PostgreSQL by using the Helm chart
**Note:** Perform this step only if you have skipped the previous step.

If you do not use an externally managed PostgreSQL database, the Helm chart provides a PostgreSQL instance during deployment. 
This approach involves the following actions:
- PostgreSQL is deployed within the Kubernetes cluster.
- The PostgreSQL deployment, including the database, schema, and persistence, is managed
through Helm values.
- The required database schema and tables are automatically created during deployment
- No external database setup is required

Before deployment, you only need to update the values.yaml file.

To use CloudNativePG, set `postgres.enabled` and `postgres.installOperator` to `true`.
One Helm release installs the operator in `cnpg-system`, then creates the
CloudNativePG cluster, PostgreSQL pods, services, and secrets in the application
namespace:

```bash
helm upgrade --install subjectcontact . \
  --namespace cnpg-poc \
  -f values.yaml \
  --wait \
  --timeout 10m
```

To enable PostgreSQL deployment, update the following section in `values.yaml`:

```yaml
postgres:
  enabled: true
  installOperator: true
  storage:
    storageClassName: "ebs-sc"
    size: 20Gi
```
Parameter Description

| Parameter | Description |
|-----------|-------------|
| `postgres.enabled` | Creates and manages a CloudNativePG cluster. |
| `postgres.installOperator` | Installs the CloudNativePG operator. Leave this disabled if the operator is already installed. |
| `postgres.storage.storageClassName` | StorageClass used for PostgreSQL data. Leave empty to use the cluster default. |
| `postgres.storage.size` | Persistent storage allocated to each PostgreSQL instance. |

#### 5. Configure PostgreSQL backup
CloudNativePG supports CSI volume snapshots and object-store backups. Select
the mechanism with `postgres.backup.method`; `volumeSnapshot` is the default.
CloudNativePG schedules backups with a six-field cron expression that includes
seconds.

```yaml
postgres:
  backup:
    enabled: true
    method: volumeSnapshot
    volumeSnapshot:
      className: "csi-aws-vsc"
      snapshotOwnerReference: none
      online: true
      onlineConfiguration:
        immediateCheckpoint: false
        waitForArchive: true
    scheduledBackup:
      schedule: "0 0 2 * * *"
      backupOwnerReference: self
      immediate: false
      suspend: false
```

CNPG does not apply a retention policy to volume snapshots.
`snapshotOwnerReference: none` preserves them when the originating CNPG
`Backup` or `Cluster` resource is deleted; lifecycle cleanup must be managed
separately.

For object-store backups, set `method: objectStore`, select `aws`, `azure`, or
`gcs`, and configure that provider's destination and credentials. Object-store
backups continuously archive WAL files and support Barman retention policies.
Credential fields reference pre-existing Secrets in the application namespace;
workload identity can be configured with `postgres.serviceAccountTemplate`.

```yaml
postgres:
  serviceAccountTemplate:
    metadata:
      annotations:
        eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/cnpg-backup
  backup:
    enabled: true
    method: objectStore
    objectStore:
      provider: aws
      retentionPolicy: "30d"
      aws:
        destinationPath: s3://my-backup-bucket/postgresql
        s3Credentials:
          inheritFromIAMRole: true
    scheduledBackup:
      schedule: "0 0 2 * * *"
```

Azure uses `objectStore.azure.azureCredentials` and GCS uses
`objectStore.gcs.googleCredentials`. The complete provider options and Secret
selector examples are documented in `values.yaml`.

### Shared CNPG cluster-apply RBAC

CNPG-enabled releases with the same Helm release name reuse the cluster-scoped
`<release>-cnpg-cluster-apply` ClusterRole. The first release creates the role;
later releases detect it and create only a namespace-specific
ClusterRoleBinding for their cluster-apply ServiceAccount. A release that owns
the role continues to render and reconcile it during upgrades.

The shared ClusterRole uses `helm.sh/resource-policy: keep`, so uninstalling its
original release does not break other namespaces that still reference it.
After all releases and their namespace-specific bindings have been removed,
delete an unused retained ClusterRole manually.

#### 6. Create Kubernetes secrets
You must create the required Kubernetes secrets before you deploy the Helm chart.

#### Access Point Secret
An access point secret contains configuration data that is used by API users and on-premises
agents to connect to SAS Customer Intelligence 360. The access point secret stores information
about tenant authentication.

Create the access point secret:

```bash
kubectl create secret generic access-point-secret \
  --from-literal=tenant-id=<TENANT_ID> \
  --from-literal=client-secret=<CLIENT_SECRET> \
  -n <namespace>
```
Replace <TENANT_ID>, <CLIENT_SECRET>, and <namespace> with the appropriate values for
your environment. 

#### API User Secret
The API user secret is required to generate a temporary JSON Web Token (JWT) to authenticate
some REST APIs.
Create the API user secret:

```bash
kubectl create secret generic api-user-secret \
  --from-literal=user-id=<API_USER_ID> \
  --from-literal=user-secret=<API_USER_SECRET> \
  -n <namespace>
```
Replace <API_USER_ID>, <API_USER_SECRET>, and <namespace> with the appropriate values for
your environment


#### Database Secret
Skip this step if you are deploying PostgreSQL by using a Helm chart.

Create the database secret:

```bash
kubectl create secret generic subjectcontact-db-secret \
  -n <namespace> \
  --from-literal=db.secrets="host=<DB_HOST> user=<DB_USER> password=<DB_PASSWORD> dbname=<DB_NAME> port=<DB_PORT> sslmode=<SSL_MODE> search_path=<SCHEMA>"
```

Sample command:

```bash
kubectl create secret generic subjectcontact-db-secret \
  -n testasc \
  --from-literal=db.secrets="host=postgres-service user=dbmsowner password=mypassword dbname=mydb port=5432 sslmode=disable search_path=contactresponse"
```
Replace the placeholder values (<namespace>, <DB_HOST>, <DB_USER>, <DB_PASSWORD>,
<DB_NAME>, <DB_PORT>, <SSL_MODE>, and <SCHEMA>) with the appropriate configuration for
your environment

#### 7. Verify Helm installation
Verify the Helm installation:

```bash
helm version
```
#### 8. Verify network access
Ensure that the Kubernetes cluster can access the following items:
- the public Helm repository
- the external API gateway that is specified by ExternalGatewayHost

**Note:** The Helm chart automatically creates the image pull secret during deployment. This secret is
used to authenticate AWS ECR to pull decision images.

## Set up the Helm repository
Add the SAS 360 Marketing Decisioning Helm repository.

```bash
helm repo add ci360-helm-charts https://sassoftware.github.io/ci360-helm-charts/packages
```
Update the Helm repository.
```bash
helm repo update
```

Verify that the chart is available:

```bash
helm search repo ci360-helm-charts/sas-marketing-decisioning
```

## Customize and deploy the Helm chart
1) Download the default Helm values file and save it locally:

```bash
helm show values ci360-helm-charts/sas-marketing-decisioning > values.yaml
```

2) Update the following parameters in `values.yaml`:

Sample values.yaml
```yaml
global:
  imagePullSecretName: image-pull-secret
  ExternalGatewayHost: "extapigwservice-demo.cidemo.sas.com"
  accessPointSecretName: access-point-secret
  apiUserSecretName: api-user-secret
  dbsecretname: subjectcontact-db-secret
```

| Parameter | Description |
|-----------|-------------|
| `imagePullSecretName` | Name of the image pull secret. The Helm chart creates this secret automatically to authenticate and pull images from AWS ECR. If this secret is missing, it causes an `ImagePullBackOff` error. |
| `ExternalGatewayHost` | External API gateway host for the target environment. |
| `accessPointSecretName` | Name of the secret that contains tenant authentication information. |
| `apiUserSecretName` | Name of the secret that contains API user credentials. |
| `dbsecretname` | Refers to the database secret used for database connectivity. If this value is incorrect, the application fails to start. |


To find the external API gateway host
- sign in to SAS Customer Intelligence 360
- go to Administration > General Settings > External Access > Access Points
- Make note of the value in the External gateway host field. This is the root URL for any API
calls that go through the external API gateway. Use the value in this field when you see the
variable <external gateway host> in the documentation.

## Deploy the Helm Chart
Before deploying, it is recommended you test (dry run) your configuration.

```bash
helm upgrade --install decisioning ci360-helm-charts/sas-marketing-decisioning \
  -n <namespace> \
  -f values.yaml \
  --dry-run
```
Replace `<namespace>` with the target namespace.
- If the test completes without errors, your configuration is ready for deployment.
- If errors are reported, correct them in values.yaml and repeat the test.

When the test is successful, proceed with the actual deployment by using the following
command:

```bash
helm upgrade --install <release-name> ci360-helm-charts/sas-marketing-decisioning \
  -n <namespace> \
  -f values.yaml \
  --wait --timeout 10m
```
Replace <release-name> and `<namespace>` with the appropriate values. The --wait and --
timeout options ensure that Helm waits for all resources to be ready before completing the
deployment.

## Verify the deployment
Check the status of the deployed resources:

```bash
kubectl get pods -n <namespace>
helm list -n <namespace>
```
Replace `<namespace>` with the appropriate value

Expected results:
- All pods are in the Running state.
- No pods are in the CrashLoopBackOff state.
- No pods are in the ImagePullBackOff state.

Optional: verify the image pull secret.

```bash
kubectl get secret image-pull-secret -n <namespace>
```

## Access PostgreSQL database
If you configured PostgreSQL database by using the Helm chart, you can access the database for troubleshooting purposes.

1) Retrieve database credentials:

If you need PostgreSQL database credentials, use the following values:
- Username: `postgres`
- Password: Retrieve it from the Kubernetes secret `subjectcontact-cnpg-auth`

To retrieve and decode the password, run the following command:

```bash
kubectl get secret subjectcontact-cnpg-auth -n <namespace> -o jsonpath="{.data.password}" | base64 --decode
```

For CloudNativePG, Helm generates the database password once and stores it in
the retained `subjectcontact-cnpg-auth` Secret. Helm reuses that password on
upgrades, and CNPG uses the same credential after a PostgreSQL image upgrade or
primary failover:

```bash
kubectl get secret subjectcontact-cnpg-auth -n <namespace> -o jsonpath="{.data.password}" | base64 --decode
```

Do not delete this Secret. Deleting it, or deleting its namespace, is outside
the password-persistence guarantee and requires explicit credential recovery
before downstream applications can reconnect.

2) Connect to the PostgreSQL database:

To connect to the PostgreSQL database running inside the Kubernetes cluster, use Kubernetes
port-forwarding and connect through a PostgreSQL client such as pgAdmin.

Verify PostgreSQL services.
Run the following command to list the Kubernetes services in the namespace:
```bash
kubectl get svc -n <namespace>
kubectl port-forward svc/<release-name>-cnpg-rw -n <namespace> 5432:5432
```
The `<release-name>-cnpg-rw` service always routes to the current primary.

Create a port forward to PostgreSQL
```bash
kubectl port-forward svc/<release-name>-cnpg-rw -n <namespace> 5432:5432
```
Connect by using pgAdmin or any PostgreSQL client.

Use the following connection details in pgAdmin or another PostgreSQL client:
- Host: `localhost`
- Port: `5432`
- Username: `postgres`
- Password: Retrieved from Kubernetes secret `subjectcontact-cnpg-auth`

## Troubleshooting
Troubleshoot common pod issues during deployment:
- If pods are in `ImagePullBackOff`, verify that the image pull secret exists.
```bash
kubectl get secret -n <namespace>
```
- If pods are in `CrashLoopBackOff`, check the pod logs.

```bash
kubectl logs <pod-name> -n <namespace>
```