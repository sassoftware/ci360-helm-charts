{{/*
Resolve the ECR registry URL from global.ExternalGatewayHost.
Returns the full registry host: <accountID>.dkr.ecr.<region>.amazonaws.com
*/}}
{{- define "sas-marketing-decisioning.ecrRegistry" -}}
{{- $registryMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $registry := get $registryMap $host -}}
{{- if $registry -}}
{{- $registry -}}
{{- else -}}
{{- fail (printf "Unknown ExternalGatewayHost '%s'. Valid values: extapigwservice-dev.cidev.sas.us, extapigwservice-stage.cistage.sas.com, extapigwservice-prod.ci360.sas.com, extapigwservice-training.ci360.sas.com, extapigwservice-eu-prod.ci360.sas.com, extapigwservice-apn-prod.ci360.sas.com, extapigwservice-syd-prod.ci360.sas.com, extapigwservice-mum-prod.ci360.sas.com, extapigwservice-demo.cidemo.sas.com" $host) -}}
{{- end -}}
{{- end -}}

{{/*
Validate the customer's PostgreSQL selection:
  1. When the chart does not install the operator, its CRDs must exist.
  2. CNPG backup method and object-store provider settings must be valid.
Called unconditionally from templates/validate-postgres-choice.yaml so it
runs on every install/upgrade/template regardless of which options are set.
*/}}
{{- define "sas-marketing-decisioning.validatePostgresChoice" -}}
{{- $cnpgEnabled := .Values.postgres.enabled -}}
{{- $installOperator := .Values.postgres.installOperator -}}
{{- if and $cnpgEnabled (not $installOperator) -}}
{{- $crd := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "clusters.postgresql.cnpg.io" -}}
{{- if not $crd -}}
{{- fail "postgres.enabled=true but the CloudNativePG operator CRDs were not found and postgres.installOperator=false. Set postgres.installOperator=true or install the operator first." -}}
{{- end -}}
{{- end -}}
{{- if and $cnpgEnabled .Values.postgres.backup.enabled -}}
{{- $method := .Values.postgres.backup.method -}}
{{- if not (has $method (list "volumeSnapshot" "objectStore")) -}}
{{- fail "postgres.backup.method must be one of: volumeSnapshot, objectStore." -}}
{{- end -}}
{{- if eq $method "objectStore" -}}
{{- $provider := .Values.postgres.backup.objectStore.provider -}}
{{- if not (has $provider (list "aws" "azure" "gcs")) -}}
{{- fail "postgres.backup.objectStore.provider must be one of: aws, azure, gcs." -}}
{{- end -}}
{{- $providerConfig := get .Values.postgres.backup.objectStore $provider -}}
{{- if not (get $providerConfig "destinationPath") -}}
{{- fail (printf "postgres.backup.objectStore.%s.destinationPath is required when object-store backups are enabled." $provider) -}}
{{- end -}}
{{- $retentionPolicy := .Values.postgres.backup.objectStore.retentionPolicy -}}
{{- if and $retentionPolicy (not (regexMatch "^[1-9][0-9]*[dwm]$" $retentionPolicy)) -}}
{{- fail "postgres.backup.objectStore.retentionPolicy must be a positive number followed by d, w, or m (for example, 30d)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Build the CloudNativePG PostgreSQL image from the user-supplied version.
*/}}
{{- define "sas-marketing-decisioning.cnpgPostgresImage" -}}
{{- $version := required "postgres.postgresVersion is required" .Values.postgres.postgresVersion -}}
{{- printf "ghcr.io/cloudnative-pg/postgresql:%v" $version -}}
{{- end -}}

{{/*
Renders the CNPG Cluster manifest for the post-install apply Job.
*/}}
{{- define "sas-marketing-decisioning.cnpgClusterManifest" -}}
{{- $clusterName := .Values.postgres.clusterName | default (printf "%s-cnpg" .Release.Name) -}}
{{- $authSecretName := "subjectcontact-cnpg-auth" -}}
{{- $dbName := .Values.postgres.database | default "contactresponse" -}}
{{- $dbUser := .Values.postgres.owner | default "postgres" -}}
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: {{ $clusterName }}
  namespace: {{ .Release.Namespace }}
  labels:
    app.kubernetes.io/managed-by: Helm
    {{- with .Values.postgres.extraLabels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  {{- if eq $dbUser "postgres" }}
  enableSuperuserAccess: true
  superuserSecret:
    name: {{ $authSecretName }}
  {{- end }}
  {{- with .Values.postgres.extraLabels }}
  inheritedMetadata:
    labels:
      {{- toYaml . | nindent 6 }}
  {{- end }}
  description: {{ .Values.postgres.description | default "CloudNativePG cluster managed by sas-marketing-decisioning" | quote }}
  instances: {{ .Values.postgres.instances }}
  imageName: {{ include "sas-marketing-decisioning.cnpgPostgresImage" . | quote }}
  {{- with .Values.postgres.highAvailability }}
  {{- with .primaryUpdateStrategy }}
  primaryUpdateStrategy: {{ . }}
  {{- end }}
  {{- with .primaryUpdateMethod }}
  primaryUpdateMethod: {{ . }}
  {{- end }}
  {{- if not (kindIs "invalid" .failoverDelay) }}
  failoverDelay: {{ .failoverDelay }}
  {{- end }}
  {{- if not (kindIs "invalid" .switchoverDelay) }}
  switchoverDelay: {{ .switchoverDelay }}
  {{- end }}
  {{- with .replicationSlots }}
  replicationSlots:
    {{- with .highAvailability }}
    highAvailability:
      enabled: {{ .enabled }}
      {{- with .slotPrefix }}
      slotPrefix: {{ . | quote }}
      {{- end }}
      {{- if not (kindIs "invalid" .synchronizeLogicalDecoding) }}
      synchronizeLogicalDecoding: {{ .synchronizeLogicalDecoding }}
      {{- end }}
    {{- end }}
    {{- with .synchronizeReplicas }}
    synchronizeReplicas:
      enabled: {{ .enabled }}
    {{- end }}
    {{- with .updateInterval }}
    updateInterval: {{ . }}
    {{- end }}
  {{- end }}
  {{- end }}
  storage:
    size: {{ .Values.postgres.storage.size }}
    {{- if .Values.postgres.storage.storageClassName }}
    storageClass: {{ .Values.postgres.storage.storageClassName }}
    {{- end }}
  {{- if .Values.postgres.affinity.enablePodAntiAffinity }}
  affinity:
    enablePodAntiAffinity: {{ .Values.postgres.affinity.enablePodAntiAffinity }}
    topologyKey: {{ .Values.postgres.affinity.topologyKey }}
  {{- end }}
  resources:
    {{- toYaml .Values.postgres.resources | nindent 4 }}
  bootstrap:
    initdb:
      database: {{ $dbName }}
      owner: {{ $dbUser }}
      {{- /* This must also be set for owner=postgres. Otherwise CNPG creates
             <cluster>-app and that generated password supersedes the retained
             superuser credential during bootstrap. */}}
      secret:
        name: {{ $authSecretName }}
      postInitApplicationSQLRefs:
        configMapRefs:
          - name: {{ .Release.Name }}-pg-initdb
            key: init-schema.sql
  {{- $pgParams := deepCopy (.Values.postgres.postgresqlParameters | default dict) }}
  {{- if .Values.global.reporting.enabled }}
  {{- /* CDC / reporting requires logical replication. These values take
         precedence over user-supplied values to guarantee CDC works. */}}
  {{- $_ := set $pgParams "wal_level" "logical" }}
  {{- $_ = set $pgParams "max_replication_slots" "10" }}
  {{- $_ = set $pgParams "max_wal_senders" "10" }}
  {{- /* Required for Postgres 17+ Native Failover Slots / CNPG sync */}}
  {{- $_ = set $pgParams "hot_standby_feedback" "on" }}
  {{- $_ = set $pgParams "sync_replication_slots" "on" }}
  {{- end }}
  {{- if $pgParams }}
  postgresql:
    parameters:
      {{- toYaml $pgParams | nindent 6 }}
  {{- end }}
  {{- if .Values.postgres.monitoring.enablePodMonitor }}
  monitoring:
    enablePodMonitor: true
  {{- end }}
  {{- with .Values.postgres.serviceAccountTemplate }}
  serviceAccountTemplate:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if .Values.postgres.backup.enabled }}
  backup:
    {{- if eq .Values.postgres.backup.method "volumeSnapshot" }}
    volumeSnapshot:
      {{- with .Values.postgres.backup.volumeSnapshot.className }}
      className: {{ . | quote }}
      {{- end }}
      {{- toYaml (omit .Values.postgres.backup.volumeSnapshot "className") | nindent 6 }}
    {{- else }}
    {{- $objectStore := .Values.postgres.backup.objectStore }}
    {{- $providerConfig := get $objectStore $objectStore.provider }}
    barmanObjectStore:
      destinationPath: {{ $providerConfig.destinationPath | quote }}
      {{- with $providerConfig.endpointURL }}
      endpointURL: {{ . | quote }}
      {{- end }}
      {{- if eq $objectStore.provider "aws" }}
      s3Credentials:
        {{- toYaml $providerConfig.s3Credentials | nindent 8 }}
      {{- else if eq $objectStore.provider "azure" }}
      azureCredentials:
        {{- toYaml $providerConfig.azureCredentials | nindent 8 }}
      {{- else }}
      googleCredentials:
        {{- toYaml $providerConfig.googleCredentials | nindent 8 }}
      {{- end }}
    {{- with $objectStore.retentionPolicy }}
    retentionPolicy: {{ . | quote }}
    {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Renders the CNPG ScheduledBackup manifest for the post-install apply Job.
*/}}
{{- define "sas-marketing-decisioning.cnpgScheduledBackupManifest" -}}
{{- $clusterName := .Values.postgres.clusterName | default (printf "%s-cnpg" .Release.Name) -}}
apiVersion: postgresql.cnpg.io/v1
kind: ScheduledBackup
metadata:
  name: {{ printf "%s-backup" $clusterName | trunc 63 | trimSuffix "-" }}
  namespace: {{ .Release.Namespace }}
  labels:
    app.kubernetes.io/managed-by: Helm
spec:
  cluster:
    name: {{ $clusterName }}
  method: {{ ternary "volumeSnapshot" "barmanObjectStore" (eq .Values.postgres.backup.method "volumeSnapshot") }}
  {{- toYaml .Values.postgres.backup.scheduledBackup | nindent 2 }}
{{- end -}}