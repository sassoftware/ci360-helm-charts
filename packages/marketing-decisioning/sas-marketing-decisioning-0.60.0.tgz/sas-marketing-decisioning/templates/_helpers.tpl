{{/*
Resolve the ECR registry URL from global.ExternalGatewayHost.
Returns the full registry host: <accountID>.dkr.ecr.<region>.amazonaws.com
*/}}
{{- define "sas-marketing-decisioning.ecrRegistry" -}}
{{- $registryMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $registry := get $registryMap $host -}}
{{- if $registry -}}
{{- $registry -}}
{{- else -}}
{{- fail (printf "Unknown ExternalGatewayHost '%s'. Valid values: extapigwservice-dev.cidev.sas.us, extapigwservice-stage.cistage.sas.com, extapigwservice-prod.ci360.sas.com, extapigwservice-training.ci360.sas.com, extapigwservice-eu-prod.ci360.sas.com, extapigwservice-apn-prod.ci360.sas.com, extapigwservice-syd-prod.ci360.sas.com, extapigwservice-mum-prod.ci360.sas.com, extapigwservice-demo.cidemo.sas.com" $host) -}}
{{- end -}}
{{- end -}}

{{/*
Validate the customer's PostgreSQL selection:
  1. postgresql-ha.enabled and cnpg.enabled cannot both be true.
  2. When the chart does not install the operator, its CRDs must exist.
  3. CNPG backup method and object-store provider settings must be valid.
Called unconditionally from templates/validate-postgres-choice.yaml so it
runs on every install/upgrade/template regardless of which options are set.
*/}}
{{- define "sas-marketing-decisioning.validatePostgresChoice" -}}
{{- $bitnami := index .Values "postgresql-ha" "enabled" -}}
{{- $cnpgEnabled := .Values.cnpg.enabled -}}
{{- $installOperator := .Values.cnpg.installOperator -}}
{{- if and $bitnami $cnpgEnabled -}}
{{- fail "Only one of postgresql-ha.enabled or cnpg.enabled may be true. Set the other to false, or leave both false to bring your own PostgreSQL via a pre-existing global.dbsecretname Secret." -}}
{{- end -}}
{{- if and $cnpgEnabled (not $installOperator) -}}
{{- $crd := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "clusters.postgresql.cnpg.io" -}}
{{- if not $crd -}}
{{- fail "cnpg.enabled=true but the CloudNativePG operator CRDs were not found and cnpg.installOperator=false. Set cnpg.installOperator=true or install the operator first." -}}
{{- end -}}
{{- end -}}
{{- if and $cnpgEnabled .Values.cnpg.backup.enabled -}}
{{- $method := .Values.cnpg.backup.method -}}
{{- if not (has $method (list "volumeSnapshot" "objectStore")) -}}
{{- fail "cnpg.backup.method must be one of: volumeSnapshot, objectStore." -}}
{{- end -}}
{{- if eq $method "objectStore" -}}
{{- $provider := .Values.cnpg.backup.objectStore.provider -}}
{{- if not (has $provider (list "aws" "azure" "gcs")) -}}
{{- fail "cnpg.backup.objectStore.provider must be one of: aws, azure, gcs." -}}
{{- end -}}
{{- $providerConfig := get .Values.cnpg.backup.objectStore $provider -}}
{{- if not (get $providerConfig "destinationPath") -}}
{{- fail (printf "cnpg.backup.objectStore.%s.destinationPath is required when object-store backups are enabled." $provider) -}}
{{- end -}}
{{- $retentionPolicy := .Values.cnpg.backup.objectStore.retentionPolicy -}}
{{- if and $retentionPolicy (not (regexMatch "^[1-9][0-9]*[dwm]$" $retentionPolicy)) -}}
{{- fail "cnpg.backup.objectStore.retentionPolicy must be a positive number followed by d, w, or m (for example, 30d)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Build the CloudNativePG PostgreSQL image from the user-supplied version.
*/}}
{{- define "sas-marketing-decisioning.cnpgPostgresImage" -}}
{{- $version := required "cnpg.postgresVersion is required" .Values.cnpg.postgresVersion -}}
{{- printf "ghcr.io/cloudnative-pg/postgresql:%v" $version -}}
{{- end -}}

{{/*
Renders the CNPG Cluster manifest for the post-install apply Job.
*/}}
{{- define "sas-marketing-decisioning.cnpgClusterManifest" -}}
{{- $clusterName := .Values.cnpg.clusterName | default (printf "%s-cnpg" .Release.Name) -}}
{{- $authSecretName := "subjectcontact-cnpg-auth" -}}
{{- $dbName := .Values.cnpg.database | default "contactresponse" -}}
{{- $dbUser := .Values.cnpg.owner | default "postgres" -}}
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: {{ $clusterName }}
  namespace: {{ .Release.Namespace }}
  labels:
    app.kubernetes.io/managed-by: Helm
    {{- with .Values.cnpg.extraLabels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  {{- if eq $dbUser "postgres" }}
  enableSuperuserAccess: true
  superuserSecret:
    name: {{ $authSecretName }}
  {{- end }}
  {{- with .Values.cnpg.extraLabels }}
  inheritedMetadata:
    labels:
      {{- toYaml . | nindent 6 }}
  {{- end }}
  description: {{ .Values.cnpg.description | default "CloudNativePG cluster managed by sas-marketing-decisioning" | quote }}
  instances: {{ .Values.cnpg.instances }}
  imageName: {{ include "sas-marketing-decisioning.cnpgPostgresImage" . | quote }}
  {{- with .Values.cnpg.highAvailability }}
  {{- with .primaryUpdateStrategy }}
  primaryUpdateStrategy: {{ . }}
  {{- end }}
  {{- with .primaryUpdateMethod }}
  primaryUpdateMethod: {{ . }}
  {{- end }}
  {{- if not (kindIs "invalid" .failoverDelay) }}
  failoverDelay: {{ .failoverDelay }}
  {{- end }}
  {{- if not (kindIs "invalid" .switchoverDelay) }}
  switchoverDelay: {{ .switchoverDelay }}
  {{- end }}
  {{- with .replicationSlots }}
  replicationSlots:
    {{- with .highAvailability }}
    highAvailability:
      enabled: {{ .enabled }}
      {{- with .slotPrefix }}
      slotPrefix: {{ . | quote }}
      {{- end }}
      {{- if not (kindIs "invalid" .synchronizeLogicalDecoding) }}
      synchronizeLogicalDecoding: {{ .synchronizeLogicalDecoding }}
      {{- end }}
    {{- end }}
    {{- with .synchronizeReplicas }}
    synchronizeReplicas:
      enabled: {{ .enabled }}
    {{- end }}
    {{- with .updateInterval }}
    updateInterval: {{ . }}
    {{- end }}
  {{- end }}
  {{- end }}
  storage:
    size: {{ .Values.cnpg.storage.size }}
    {{- if .Values.cnpg.storage.storageClassName }}
    storageClass: {{ .Values.cnpg.storage.storageClassName }}
    {{- end }}
  {{- if .Values.cnpg.affinity.enablePodAntiAffinity }}
  affinity:
    enablePodAntiAffinity: {{ .Values.cnpg.affinity.enablePodAntiAffinity }}
    topologyKey: {{ .Values.cnpg.affinity.topologyKey }}
  {{- end }}
  resources:
    {{- toYaml .Values.cnpg.resources | nindent 4 }}
  bootstrap:
    initdb:
      database: {{ $dbName }}
      owner: {{ $dbUser }}
      {{- /* This must also be set for owner=postgres. Otherwise CNPG creates
             <cluster>-app and that generated password supersedes the retained
             superuser credential during bootstrap. */}}
      secret:
        name: {{ $authSecretName }}
      postInitApplicationSQLRefs:
        configMapRefs:
          - name: {{ .Release.Name }}-pg-initdb
            key: init-schema.sql
  {{- $pgParams := deepCopy (.Values.cnpg.postgresqlParameters | default dict) }}
  {{- if .Values.global.reporting.enabled }}
  {{- /* CDC / reporting requires logical replication. These mirror the
         override.conf applied to Bitnami postgresql-ha and take precedence
         over any user-supplied values to guarantee CDC works. */}}
  {{- $_ := set $pgParams "wal_level" "logical" }}
  {{- $_ = set $pgParams "max_replication_slots" "10" }}
  {{- $_ = set $pgParams "max_wal_senders" "10" }}
  {{- /* Required for Postgres 17+ Native Failover Slots / CNPG sync */}}
  {{- $_ = set $pgParams "hot_standby_feedback" "on" }}
  {{- $_ = set $pgParams "sync_replication_slots" "on" }}
  {{- end }}
  {{- if $pgParams }}
  postgresql:
    parameters:
      {{- toYaml $pgParams | nindent 6 }}
  {{- end }}
  {{- if .Values.cnpg.monitoring.enablePodMonitor }}
  monitoring:
    enablePodMonitor: true
  {{- end }}
  {{- with .Values.cnpg.serviceAccountTemplate }}
  serviceAccountTemplate:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if .Values.cnpg.backup.enabled }}
  backup:
    {{- if eq .Values.cnpg.backup.method "volumeSnapshot" }}
    volumeSnapshot:
      {{- with .Values.cnpg.backup.volumeSnapshot.className }}
      className: {{ . | quote }}
      {{- end }}
      {{- toYaml (omit .Values.cnpg.backup.volumeSnapshot "className") | nindent 6 }}
    {{- else }}
    {{- $objectStore := .Values.cnpg.backup.objectStore }}
    {{- $providerConfig := get $objectStore $objectStore.provider }}
    barmanObjectStore:
      destinationPath: {{ $providerConfig.destinationPath | quote }}
      {{- with $providerConfig.endpointURL }}
      endpointURL: {{ . | quote }}
      {{- end }}
      {{- if eq $objectStore.provider "aws" }}
      s3Credentials:
        {{- toYaml $providerConfig.s3Credentials | nindent 8 }}
      {{- else if eq $objectStore.provider "azure" }}
      azureCredentials:
        {{- toYaml $providerConfig.azureCredentials | nindent 8 }}
      {{- else }}
      googleCredentials:
        {{- toYaml $providerConfig.googleCredentials | nindent 8 }}
      {{- end }}
    {{- with $objectStore.retentionPolicy }}
    retentionPolicy: {{ . | quote }}
    {{- end }}
    {{- end }}
  {{- end }}
{{- end -}}

{{/*
Renders the CNPG ScheduledBackup manifest for the post-install apply Job.
*/}}
{{- define "sas-marketing-decisioning.cnpgScheduledBackupManifest" -}}
{{- $clusterName := .Values.cnpg.clusterName | default (printf "%s-cnpg" .Release.Name) -}}
apiVersion: postgresql.cnpg.io/v1
kind: ScheduledBackup
metadata:
  name: {{ printf "%s-backup" $clusterName | trunc 63 | trimSuffix "-" }}
  namespace: {{ .Release.Namespace }}
  labels:
    app.kubernetes.io/managed-by: Helm
spec:
  cluster:
    name: {{ $clusterName }}
  method: {{ ternary "volumeSnapshot" "barmanObjectStore" (eq .Values.cnpg.backup.method "volumeSnapshot") }}
  {{- toYaml .Values.cnpg.backup.scheduledBackup | nindent 2 }}
{{- end -}}