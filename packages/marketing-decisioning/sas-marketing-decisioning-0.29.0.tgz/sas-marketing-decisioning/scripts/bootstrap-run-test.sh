#!/bin/sh
# =============================================================================
# bootstrap-run-test.sh — Helm Smoke Test Runner
#
# Narrative:
#   1. Pull python:3.12-slim from Docker Hub  (done by Kubernetes / subjectcontact-smoke-job.yaml)
#   2. Install pytest and requests            (pip install below)
#   3. Run pytest smoke test                  (pytest /tmp/smoke/)
#
# This script is delivered to the pod via b64enc env var (EXECUTE_SH_B64).
# The Python test files are delivered the same way (CONFTEST_B64, SMOKE_TEST_B64).
# No ConfigMap, no custom image, no heredocs.
#
# Environment variables injected by subjectcontact-smoke-job.yaml:
#   SERVICE_BASE_URL  — full service URL e.g. http://subjectcontact.<ns>.svc.cluster.local:8080/marketingDecisioningSubjectContact
#   INIT_PY_B64       — base64-encoded tests/subjectcontact/smoke/__init__.py
#   CONFTEST_B64      — base64-encoded tests/subjectcontact/smoke/conftest.py
#   SMOKE_TEST_B64    — base64-encoded tests/subjectcontact/smoke/smoke_test.py
#
# Local usage:
#   export SERVICE_BASE_URL="http://localhost:8080/marketingDecisioningSubjectContact"
#   export INIT_PY_B64=$(base64 -w0 charts/service/tests/subjectcontact/smoke/__init__.py)
#   export CONFTEST_B64=$(base64 -w0 charts/service/tests/subjectcontact/smoke/conftest.py)
#   export SMOKE_TEST_B64=$(base64 -w0 charts/service/tests/subjectcontact/smoke/smoke_test.py)
#   sh charts/service/scripts/bootstrap-run-test.sh
# =============================================================================

set -e

# ------------------------------------------------------------------------------
# Step 1: Verify SERVICE_BASE_URL is set
# ------------------------------------------------------------------------------
if [ -z "$SERVICE_BASE_URL" ]; then
    echo "ERROR: SERVICE_BASE_URL is not set."
    echo "  This variable is set via the env: section in subjectcontact-smoke-job.yaml."
    echo "  Check charts/service/templates/subjectcontact-smoke-job.yaml for the SERVICE_BASE_URL env var."
    exit 1
fi

echo "======================================================"
echo "  Smoke Test — sas-marketing-decisioning"
echo "  Service URL : $SERVICE_BASE_URL"
echo "  Python      : $(python --version 2>&1)"
echo "======================================================"

# ------------------------------------------------------------------------------
# Step 2: Decode Python test files into /tmp/smoke/
# ------------------------------------------------------------------------------
SMOKE_DIR="/tmp/smoke"
mkdir -p "$SMOKE_DIR"

# Decode each file individually with an explicit error message on failure.
# printf '%s' avoids the trailing newline that echo adds, which can corrupt base64 input.
if ! printf '%s' "$INIT_PY_B64"    | base64 -d > "${SMOKE_DIR}/__init__.py"; then
    echo "ERROR: Failed to decode INIT_PY_B64. Check the env var in subjectcontact-smoke-job.yaml."
    exit 1
fi
if ! printf '%s' "$CONFTEST_B64"   | base64 -d > "${SMOKE_DIR}/conftest.py"; then
    echo "ERROR: Failed to decode CONFTEST_B64. Check the env var in subjectcontact-smoke-job.yaml."
    exit 1
fi
if ! printf '%s' "$SMOKE_TEST_B64" | base64 -d > "${SMOKE_DIR}/smoke_test.py"; then
    echo "ERROR: Failed to decode SMOKE_TEST_B64. Check the env var in subjectcontact-smoke-job.yaml."
    exit 1
fi

# Guard: empty file means .Files.Get returned nothing at Helm render time
for f in "${SMOKE_DIR}/conftest.py" "${SMOKE_DIR}/smoke_test.py"; do
    if [ ! -s "$f" ]; then
        echo "ERROR: $f is empty after decode."
        echo "  .Files.Get returned no content. Verify the file exists at"
        echo "  charts/service/tests/subjectcontact/smoke/ and is not excluded by .helmignore."
        exit 1
    fi
done

echo "Test files written to $SMOKE_DIR"

# ------------------------------------------------------------------------------
# Step 3: Install prerequisites
# ------------------------------------------------------------------------------
echo "Installing prerequisites: pytest requests"
pip install --quiet --no-cache-dir pytest requests
echo "Done."
echo ""

# ------------------------------------------------------------------------------
# Step 4: Run pytest smoke test
# ------------------------------------------------------------------------------
echo "======================================================"
echo "  Running: pytest $SMOKE_DIR -v --tb=short"
echo "======================================================"
echo ""

set +e
pytest "$SMOKE_DIR" -v --tb=short
PYTEST_EXIT=$?
set -e

echo ""

# ------------------------------------------------------------------------------
# Step 5: Result
# ------------------------------------------------------------------------------
if [ "$PYTEST_EXIT" -eq 0 ]; then
    echo "======================================================"
    echo "  SMOKE TEST PASSED"
    echo "======================================================"
    exit 0
else
    echo "======================================================"
    echo "  SMOKE TEST FAILED  (exit code: $PYTEST_EXIT)"
    echo "  Check logs: kubectl logs <pod> -n <namespace>"
    echo "======================================================"
    exit 1
fi
