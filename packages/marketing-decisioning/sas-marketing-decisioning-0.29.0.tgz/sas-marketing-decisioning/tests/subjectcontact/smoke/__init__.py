# Empty file - makes tests/subjectcontact/smoke a Python package for pytest discovery
