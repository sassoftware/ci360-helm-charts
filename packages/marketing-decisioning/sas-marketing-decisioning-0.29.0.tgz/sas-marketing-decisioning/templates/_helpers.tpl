{{/*
Resolve the ECR registry URL from global.ExternalGatewayHost.
Returns the full registry host: <accountID>.dkr.ecr.<region>.amazonaws.com
*/}}
{{- define "sas-marketing-decisioning.ecrRegistry" -}}
{{- $registryMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $registry := get $registryMap $host -}}
{{- if $registry -}}
{{- $registry -}}
{{- else -}}
{{- fail (printf "Unknown ExternalGatewayHost '%s'. Valid values: extapigwservice-dev.cidev.sas.us, extapigwservice-stage.cistage.sas.com, extapigwservice-prod.ci360.sas.com, extapigwservice-training.ci360.sas.com, extapigwservice-eu-prod.ci360.sas.com, extapigwservice-apn-prod.ci360.sas.com, extapigwservice-syd-prod.ci360.sas.com, extapigwservice-mum-prod.ci360.sas.com, extapigwservice-demo.cidemo.sas.com" $host) -}}
{{- end -}}
{{- end -}}
