{{/*
Resolve the ECR image base path from global.ExternalGatewayHost.
Returns the full image base path: <accountID>.dkr.ecr.<region>.amazonaws.com/<org>/<repo-prefix>
Used as the base for container image URLs in deployments.
*/}}
{{- define "subject-contact.ecrRegistry" -}}
{{- $registryMap := dict
    "extapigwservice-dev.cidev.sas.us"       "952478859445.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-master"
    "extapigwservice-stage.cistage.sas.com"  "925052198153.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-stage"
    "extapigwservice-prod.ci360.sas.com"     "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-training.ci360.sas.com" "861073095096.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-training"
    "extapigwservice-eu-prod.ci360.sas.com"  "861073095096.dkr.ecr.eu-west-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-apn-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-northeast-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-syd-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-southeast-2.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-mum-prod.ci360.sas.com" "861073095096.dkr.ecr.ap-south-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-prod"
    "extapigwservice-demo.cidemo.sas.com"    "418062132543.dkr.ecr.us-east-1.amazonaws.com/ci360-cldeng-image-manager/shared-images-demo"
-}}
{{- $host := .Values.global.ExternalGatewayHost -}}
{{- $imageBase := get $registryMap $host -}}
{{- if $imageBase -}}
{{- $imageBase -}}
{{- else -}}
{{- fail (printf "Unknown ExternalGatewayHost '%s'. Valid values: extapigwservice-dev.cidev.sas.us, extapigwservice-stage.cistage.sas.com, extapigwservice-prod.ci360.sas.com, extapigwservice-training.ci360.sas.com, extapigwservice-eu-prod.ci360.sas.com, extapigwservice-apn-prod.ci360.sas.com, extapigwservice-syd-prod.ci360.sas.com, extapigwservice-mum-prod.ci360.sas.com, extapigwservice-demo.cidemo.sas.com" $host) -}}
{{- end -}}
{{- end -}}


{{- define "subject-contact.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "subject-contact.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "subject-contact.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "subject-contact.labels" -}}
helm.sh/chart: {{ include "subject-contact.chart" . }}
{{ include "subject-contact.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "subject-contact.selectorLabels" -}}
app.kubernetes.io/name: {{ include "subject-contact.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: subject-contact
{{- end }}
